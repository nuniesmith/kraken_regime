# Testing, Backtesting & Walk-Forward Analysis Guide

This guide covers everything you need to test your regime-aware trading strategy properly.

## Quick Start

```bash
# 1. Fetch historical data
cargo run --bin backtest_cli -- fetch --pair BTC/USD --days 90 --timeframe 15

# 2. Run backtest with realistic fees/slippage
cargo run --bin backtest_cli -- backtest --pair BTC/USD --fees standard

# 3. Run walk-forward analysis (prevents overfitting)
cargo run --bin backtest_cli -- walk-forward --pair BTC/USD --train-days 30 --test-days 7

# 4. Run unit tests
cargo test

# 5. Compare detection methods
cargo run --bin backtest_cli -- compare --pair BTC/USD
```

## Data Fetching

### CLI Usage
```bash
# Fetch 90 days of BTC/USD 15-minute data
cargo run --bin backtest_cli -- fetch \
    --pair BTC/USD \
    --days 90 \
    --timeframe 15 \
    --data-dir ./data/ohlc

# Fetch multiple pairs
for pair in BTC/USD ETH/USD SOL/USD; do
    cargo run --bin backtest_cli -- fetch --pair $pair --days 90
    sleep 2  # Rate limit
done
```

### Programmatic Usage
```rust
use kraken_regime::prelude::*;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let fetcher = KrakenDataFetcher::new();
    let storage = DataStorage::with_data_dir("./data/ohlc");
    
    let pair = TradingPair::new("BTC", "USD");
    let candles = fetcher.fetch_all(&pair, Timeframe::M15, 90).await?;
    
    storage.save_csv(&pair, Timeframe::M15, &candles)?;
    println!("Fetched {} candles", candles.len());
    
    Ok(())
}
```

### Supported Timeframes
| Timeframe | Minutes | Use Case |
|-----------|---------|----------|
| M1 | 1 | Scalping (not recommended) |
| M5 | 5 | Short-term |
| M15 | 15 | **Recommended for regime detection** |
| M30 | 30 | Swing trading |
| H1 | 60 | Position trading |
| H4 | 240 | Long-term trends |
| D1 | 1440 | Multi-week holds |

## Backtesting with Realistic Costs

### Fee Tiers
```rust
// Kraken Standard (most users)
TradingCosts::kraken_standard()  // 0.16% maker, 0.26% taker

// Kraken Intermediate ($50k+ monthly volume)
TradingCosts::kraken_intermediate()  // 0.14% maker, 0.24% taker

// Kraken Pro ($10M+ monthly volume)
TradingCosts::kraken_pro()  // 0.10% maker, 0.20% taker

// Conservative (pessimistic estimate)
TradingCosts::conservative()  // 0.20% maker, 0.30% taker + $0.10 fixed

// Zero (for comparing gross vs net returns)
TradingCosts::zero()
```

### Slippage Model
The slippage model accounts for:
- **Base spread**: Half the bid-ask spread
- **Market impact**: Larger orders move the market more
- **Size scaling**: Uses square-root model (industry standard)

```rust
// Default slippage for Kraken BTC/USD
SlippageModel::kraken_default()
// Base spread: 0.02% (~$20 on $100k BTC)
// Market impact: Scales with sqrt(order_size)

// Low slippage (limit orders, high liquidity)
SlippageModel::low_slippage()

// High slippage (market orders, low liquidity pairs)
SlippageModel::high_slippage()
```

### Running a Backtest
```rust
use kraken_regime::prelude::*;

fn main() {
    // Load data
    let storage = DataStorage::with_data_dir("./data/ohlc");
    let pair = TradingPair::new("BTC", "USD");
    let candles = storage.load(&pair, Timeframe::M15).unwrap();
    
    // Configure backtest
    let config = BacktestConfig {
        initial_capital: 10000.0,
        costs: TradingCosts::kraken_standard(),
        risk_per_trade: 0.01,  // 1% risk per trade
        max_position_size: 2500.0,
        min_position_size: 10.0,
        use_stops: true,
        log_trades: false,
        ..Default::default()
    };
    
    // Run backtest
    let mut backtester = Backtester::new(config);
    let result = backtester.run("BTC/USD", &candles);
    
    // Print results
    result.metrics.print_summary();
    
    // Access individual trades
    for trade in &result.trades {
        println!("Trade {}: {} -> {} = ${:.2}", 
            trade.id, trade.entry_price, trade.exit_price, trade.pnl_net);
    }
}
```

### Performance Metrics
The backtester calculates comprehensive metrics:

**Return Metrics:**
- Total Return (% and USD)
- CAGR (Compound Annual Growth Rate)
- Daily Return Mean/Std

**Risk Metrics:**
- Sharpe Ratio (risk-adjusted return)
- Sortino Ratio (downside-only risk)
- Calmar Ratio (return / max drawdown)
- Max Drawdown (% and USD)
- Ulcer Index (pain of drawdowns)

**Trade Statistics:**
- Win Rate
- Profit Factor (gross wins / gross losses)
- Average Win/Loss
- Largest Win/Loss
- Average Trade Duration

**Cost Breakdown:**
- Total Fees
- Total Slippage
- Costs as % of Gross Profit

## Walk-Forward Analysis

Walk-forward testing prevents overfitting by validating on out-of-sample data.

### How It Works
1. **Split data** into training and testing windows
2. **Optimize parameters** on training data
3. **Test** on out-of-sample data
4. **Roll forward** and repeat
5. **Aggregate** out-of-sample results

### CLI Usage
```bash
# Run walk-forward with 30-day training, 7-day test windows
cargo run --bin backtest_cli -- walk-forward \
    --pair BTC/USD \
    --train-days 30 \
    --test-days 7 \
    --trials 50 \
    --target sharpe
```

### Programmatic Usage
```rust
use kraken_regime::prelude::*;
use kraken_regime::backtest::walk_forward::OptimizationTarget;

fn main() {
    let storage = DataStorage::with_data_dir("./data/ohlc");
    let pair = TradingPair::new("BTC", "USD");
    let candles = storage.load(&pair, Timeframe::M15).unwrap();
    
    // Configure walk-forward
    let bars_per_day = 96;  // 15-min bars
    
    let wf_config = WalkForwardConfig {
        train_size: 30 * bars_per_day,  // 30 days training
        test_size: 7 * bars_per_day,    // 7 days testing
        step_size: 7 * bars_per_day,    // Roll forward weekly
        warmup_bars: 200,
        optimization_trials: 50,
        optimization_target: OptimizationTarget::SharpeRatio,
    };
    
    let bt_config = BacktestConfig::default();
    let wf = WalkForwardAnalysis::new(wf_config, bt_config);
    
    let result = wf.run("BTC/USD", &candles);
    result.print_summary();
}
```

### Interpreting Results

**Efficiency Ratio** (OOS Return / IS Return):
- \> 0.5: Good - Strategy generalizes well
- 0.3-0.5: OK - Some overfitting present
- < 0.3: Poor - Likely overfitted

**Consistency Score** (% profitable windows):
- \> 70%: High - Strategy is reliable
- 50-70%: Medium - Performance varies
- < 50%: Low - Strategy is inconsistent

### Optimization Targets
```rust
OptimizationTarget::SharpeRatio    // Risk-adjusted return (recommended)
OptimizationTarget::SortinoRatio   // Downside-only risk
OptimizationTarget::CalmarRatio    // Return / Max Drawdown
OptimizationTarget::TotalReturn    // Raw return (can overfit)
OptimizationTarget::ProfitFactor   // Gross wins / gross losses
OptimizationTarget::WinRate        // % winning trades
```

## Unit Tests

### Running Tests
```bash
# Run all tests
cargo test

# Run with output
cargo test -- --nocapture

# Run specific test module
cargo test indicator_tests
cargo test regime_tests
cargo test strategy_tests
cargo test cost_tests
cargo test integration_tests

# Run only quick tests
cargo test --lib

# Run benchmarks
cargo bench
```

### Test Categories

**Indicator Tests** (`src/tests.rs`):
- EMA calculation and convergence
- ATR calculation
- ADX trending/ranging detection
- Bollinger Bands basics and squeeze detection

**Regime Tests**:
- Regime detector creation
- Trending regime detection
- Ranging regime detection
- Volatile regime detection
- HMM detector
- Regime confidence values

**Strategy Tests**:
- Mean reversion creation
- Buy/sell signal generation
- Strategy router
- Strategy selection by regime

**Cost Tests**:
- Fee calculation
- Slippage model
- Entry/exit slippage direction
- Zero costs baseline

**Integration Tests**:
- Full backtest pipeline
- Regime-to-strategy flow
- Costs impact on returns

**Property Tests**:
- Extreme values handling
- Flat market handling
- Edge cases

## Comparing Detection Methods

```bash
# Compare Indicators vs HMM vs Ensemble
cargo run --bin backtest_cli -- compare --pair BTC/USD
```

This produces a comparison table showing:
- Total Return
- Sharpe Ratio
- Max Drawdown
- Win Rate

For each detection method.

## Best Practices

### 1. Always Use Walk-Forward Testing
Never trust in-sample backtest results. Walk-forward testing validates that your strategy works on unseen data.

### 2. Use Realistic Costs
Use `TradingCosts::conservative()` for initial testing to ensure profitability even with pessimistic assumptions.

### 3. Check Regime Breakdown
Look at performance by regime to understand when your strategy works:
```rust
if let Some(regime_metrics) = result.metrics.regime_metrics {
    for (regime, metrics) in regime_metrics {
        println!("{}: {} trades, {:.1}% win rate, ${:.2} P&L",
            regime, metrics.trades, metrics.win_rate, metrics.total_pnl);
    }
}
```

### 4. Validate on Multiple Assets
Test on BTC, ETH, and SOL to ensure the strategy isn't overfitted to one asset.

### 5. Check Cost Impact
Compare results with and without costs:
```bash
cargo run --bin backtest_cli -- backtest --pair BTC/USD --fees zero
cargo run --bin backtest_cli -- backtest --pair BTC/USD --fees conservative
```

### 6. Monitor Key Ratios
- Sharpe > 1.0 (good)
- Max Drawdown < 20% (acceptable)
- Win Rate > 40% with PF > 1.5 (healthy)
- Efficiency Ratio > 0.5 (not overfitted)

## Troubleshooting

### "No data found"
Run the fetch command first:
```bash
cargo run --bin backtest_cli -- fetch --pair BTC/USD --days 90
```

### "Rate limited"
Kraken limits API requests. The fetcher includes automatic rate limiting and retries, but you may need to wait between fetches.

### "Invalid pair format"
Use the format "BASE/QUOTE" like "BTC/USD", not "BTCUSD" or "XBT/USD".

### Low Sharpe Ratio
- Check if using stops (they can help or hurt depending on market)
- Try different regime detection methods
- Increase training window for walk-forward
- Review individual trades for patterns

### High Drawdown
- Reduce position size
- Use more conservative stops
- Skip trading in Uncertain regime
- Reduce risk_per_trade

## File Structure

```
kraken_regime/
├── src/
│   ├── lib.rs              # Main exports
│   ├── data/
│   │   ├── mod.rs
│   │   ├── fetcher.rs      # Kraken API data fetching
│   │   ├── storage.rs      # CSV/binary storage
│   │   └── types.rs        # Candle, Timeframe, TradingPair
│   ├── backtest/
│   │   ├── mod.rs
│   │   ├── engine.rs       # Main backtester
│   │   ├── costs.rs        # Fees and slippage
│   │   ├── metrics.rs      # Performance calculations
│   │   └── walk_forward.rs # Walk-forward analysis
│   ├── regime/             # Regime detection
│   ├── strategy/           # Trading strategies
│   ├── integration/        # Kraken integration
│   ├── bin/
│   │   └── backtest_cli.rs # CLI tool
│   └── tests.rs            # Test suite
├── examples/
│   ├── fetch_data.rs
│   ├── backtest.rs
│   └── walk_forward.rs
└── data/ohlc/              # Downloaded data (gitignored)
```
