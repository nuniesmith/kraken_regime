//! Walk-Forward Analysis Example
//!
//! Demonstrates proper out-of-sample testing to validate strategy performance.
//!
//! Walk-forward analysis:
//! 1. Split data into windows
//! 2. Optimize on training window
//! 3. Test on out-of-sample window
//! 4. Roll forward and repeat
//!
//! This prevents overfitting and gives realistic performance estimates.
//!
//! Run with: cargo run --example walk_forward

use kraken_regime::prelude::*;
use kraken_regime::backtest::walk_forward::OptimizationTarget;
use std::error::Error;

fn main() -> Result<(), Box<dyn Error>> {
    println!("╔══════════════════════════════════════════════════════════════╗");
    println!("║               WALK-FORWARD ANALYSIS                          ║");
    println!("╚══════════════════════════════════════════════════════════════╝\n");
    
    // Try to load real data first
    let storage = DataStorage::with_data_dir("./data/ohlc");
    let pair = TradingPair::new("BTC", "USD");
    let timeframe = Timeframe::M15;
    
    let candles = match storage.load(&pair, timeframe) {
        Ok(c) if c.len() > 2000 => {
            println!("✅ Using real BTC/USD data ({} candles)\n", c.len());
            c
        }
        _ => {
            println!("⚠️  Insufficient real data. Using synthetic data for demo.\n");
            println!("   Run 'cargo run --example fetch_data' to get real data.\n");
            generate_synthetic_data(5000)
        }
    };
    
    // Configure walk-forward analysis
    // For 15-min data: 96 bars = 1 day
    let bars_per_day = 96;
    
    let wf_config = WalkForwardConfig {
        train_size: 30 * bars_per_day,     // 30 days training
        test_size: 7 * bars_per_day,       // 7 days testing
        step_size: 7 * bars_per_day,       // Roll forward 7 days
        warmup_bars: 200,                   // Indicator warmup
        optimization_trials: 30,            // Trials per window
        optimization_target: OptimizationTarget::SharpeRatio,
    };
    
    println!("📊 Configuration:");
    println!("   Total candles:   {}", candles.len());
    println!("   Training window: {} days ({} bars)", 30, wf_config.train_size);
    println!("   Testing window:  {} days ({} bars)", 7, wf_config.test_size);
    println!("   Optimization:    {} trials per window", wf_config.optimization_trials);
    println!("   Target metric:   Sharpe Ratio");
    println!();
    
    // Create backtest config
    let bt_config = BacktestConfig {
        initial_capital: 10000.0,
        costs: TradingCosts::kraken_standard(),
        risk_per_trade: 0.01,
        max_position_size: 2500.0,
        min_position_size: 10.0,
        use_stops: true,
        log_trades: false,
        ..Default::default()
    };
    
    // Run walk-forward analysis
    println!("🔄 Running walk-forward analysis...\n");
    println!("   This analyzes multiple time windows to ensure strategy");
    println!("   performs well out-of-sample, not just on historical data.\n");
    
    let wf = WalkForwardAnalysis::new(wf_config, bt_config);
    let result = wf.run("BTC/USD", &candles);
    
    // Print results
    result.print_summary();
    
    // Interpretation guide
    println!("\n📚 How to Interpret Results:");
    println!("═══════════════════════════════════════════════════════════════");
    println!();
    println!("1. EFFICIENCY RATIO (OOS / IS Return):");
    println!("   > 0.5  = Good - Strategy generalizes well");
    println!("   0.3-0.5 = OK - Some overfitting present");
    println!("   < 0.3  = Poor - Likely overfitted");
    println!();
    println!("2. CONSISTENCY SCORE (% profitable windows):");
    println!("   > 70%  = High - Strategy is reliable across periods");
    println!("   50-70% = Medium - Performance varies by market conditions");
    println!("   < 50%  = Low - Strategy is inconsistent");
    println!();
    println!("3. OUT-OF-SAMPLE vs IN-SAMPLE:");
    println!("   Large gap = Strategy performs worse on unseen data");
    println!("   Small gap = Strategy generalizes well");
    println!();
    println!("4. KEY WARNINGS:");
    println!("   - If OOS return << IS return: OVERFITTING detected");
    println!("   - If consistency < 50%: Strategy unreliable");
    println!("   - If max drawdown varies wildly: Risk not consistent");
    
    Ok(())
}

/// Generate synthetic market data for demo
fn generate_synthetic_data(n: usize) -> Vec<Candle> {
    use rand::Rng;
    
    let mut rng = rand::thread_rng();
    let mut candles = Vec::with_capacity(n);
    let mut price = 50000.0;
    
    for i in 0..n {
        // Create different market phases
        let phase = (i / 500) % 4;
        
        let (trend, volatility) = match phase {
            0 => (0.002, 0.01),   // Bull market
            1 => (-0.001, 0.02),  // High volatility
            2 => (0.0, 0.005),    // Ranging
            3 => (-0.0015, 0.015), // Bear market
            _ => (0.0, 0.01),
        };
        
        // Apply trend with noise
        let change = trend + rng.gen_range(-volatility..volatility);
        price *= 1.0 + change;
        price = price.max(1000.0);  // Floor
        
        let high = price * (1.0 + rng.gen_range(0.001..0.02));
        let low = price * (1.0 - rng.gen_range(0.001..0.02));
        let open = price * (1.0 + rng.gen_range(-0.005..0.005));
        
        candles.push(Candle {
            timestamp: i as i64 * 900,  // 15-min bars
            open,
            high,
            low,
            close: price,
            volume: 100.0 + rng.gen_range(0.0..100.0),
        });
    }
    
    candles
}
