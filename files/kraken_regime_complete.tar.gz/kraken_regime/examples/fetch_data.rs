//! Fetch Data Example
//!
//! Shows how to fetch and store historical OHLCV data from Kraken.
//!
//! Run with: cargo run --example fetch_data

use kraken_regime::prelude::*;
use std::error::Error;

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    // Initialize logging
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::INFO)
        .init();
    
    println!("╔══════════════════════════════════════════════════════════════╗");
    println!("║                 KRAKEN DATA FETCHER                          ║");
    println!("╚══════════════════════════════════════════════════════════════╝\n");
    
    // Create fetcher and storage
    let fetcher = KrakenDataFetcher::new();
    let storage = DataStorage::with_data_dir("./data/ohlc");
    
    // Define pairs to fetch
    let pairs = vec![
        TradingPair::new("BTC", "USD"),
        TradingPair::new("ETH", "USD"),
        TradingPair::new("SOL", "USD"),
    ];
    
    let timeframe = Timeframe::M15;  // 15-minute candles
    let days = 30;                    // Last 30 days
    
    println!("Fetching {} days of {} data for {} pairs...\n", 
             days, timeframe, pairs.len());
    
    for pair in &pairs {
        println!("📊 Fetching {}...", pair.standard());
        
        match fetcher.fetch_all(pair, timeframe, days).await {
            Ok(candles) => {
                if candles.is_empty() {
                    println!("   ⚠️  No data returned");
                    continue;
                }
                
                // Save to storage
                match storage.save_csv(pair, timeframe, &candles) {
                    Ok(path) => {
                        let stats = kraken_regime::data::DataStats::from_candles(
                            &pair.standard(), 
                            timeframe, 
                            &candles
                        );
                        
                        println!("   ✅ Fetched {} candles", stats.count);
                        println!("      Start: {}", 
                            chrono::Utc.timestamp_opt(stats.start_time, 0)
                                .unwrap()
                                .format("%Y-%m-%d %H:%M"));
                        println!("      End:   {}", 
                            chrono::Utc.timestamp_opt(stats.end_time, 0)
                                .unwrap()
                                .format("%Y-%m-%d %H:%M"));
                        println!("      Gaps:  {}", stats.gaps.len());
                        println!("      Saved: {:?}\n", path);
                    }
                    Err(e) => {
                        println!("   ❌ Failed to save: {}", e);
                    }
                }
            }
            Err(e) => {
                println!("   ❌ Failed to fetch: {}", e);
            }
        }
        
        // Rate limiting - wait between requests
        tokio::time::sleep(tokio::time::Duration::from_secs(2)).await;
    }
    
    // List what we have
    println!("\n📁 Available data:");
    match storage.list_available() {
        Ok(list) => {
            for (pair, tf, count) in list {
                println!("   {} {} - {} candles", pair, tf, count);
            }
        }
        Err(e) => println!("   Error listing: {}", e),
    }
    
    println!("\n✅ Done! Data saved to ./data/ohlc/");
    println!("\nNext steps:");
    println!("  cargo run --example backtest     # Run backtest");
    println!("  cargo run --example walk_forward # Run walk-forward analysis");
    
    Ok(())
}

use chrono::TimeZone;
