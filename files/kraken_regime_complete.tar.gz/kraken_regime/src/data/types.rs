//! Data types for OHLCV data
//!
//! Defines standard data structures for candles and market data.

use chrono::{DateTime, TimeZone, Utc};
use serde::{Deserialize, Serialize};

/// OHLCV Candle data
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Candle {
    /// Unix timestamp (seconds)
    pub timestamp: i64,
    /// Opening price
    pub open: f64,
    /// Highest price
    pub high: f64,
    /// Lowest price
    pub low: f64,
    /// Closing price
    pub close: f64,
    /// Volume traded
    pub volume: f64,
}

impl Candle {
    /// Create a new candle
    pub fn new(timestamp: i64, open: f64, high: f64, low: f64, close: f64, volume: f64) -> Self {
        Self { timestamp, open, high, low, close, volume }
    }
    
    /// Get datetime for this candle
    pub fn datetime(&self) -> DateTime<Utc> {
        Utc.timestamp_opt(self.timestamp, 0).unwrap()
    }
    
    /// Calculate the typical price (HLC/3)
    pub fn typical_price(&self) -> f64 {
        (self.high + self.low + self.close) / 3.0
    }
    
    /// Calculate the true range
    pub fn true_range(&self, prev_close: Option<f64>) -> f64 {
        let hl = self.high - self.low;
        if let Some(pc) = prev_close {
            let hpc = (self.high - pc).abs();
            let lpc = (self.low - pc).abs();
            hl.max(hpc).max(lpc)
        } else {
            hl
        }
    }
    
    /// Is this a bullish candle?
    pub fn is_bullish(&self) -> bool {
        self.close > self.open
    }
    
    /// Is this a bearish candle?
    pub fn is_bearish(&self) -> bool {
        self.close < self.open
    }
    
    /// Calculate the body size as percentage of range
    pub fn body_ratio(&self) -> f64 {
        let range = self.high - self.low;
        if range == 0.0 {
            return 0.0;
        }
        (self.close - self.open).abs() / range
    }
    
    /// Log return from previous close
    pub fn log_return(&self, prev_close: f64) -> f64 {
        (self.close / prev_close).ln()
    }
    
    /// Simple return from previous close
    pub fn simple_return(&self, prev_close: f64) -> f64 {
        (self.close - prev_close) / prev_close
    }
}

/// Timeframe enumeration
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Timeframe {
    /// 1 minute
    M1,
    /// 5 minutes
    M5,
    /// 15 minutes
    M15,
    /// 30 minutes
    M30,
    /// 1 hour
    H1,
    /// 4 hours
    H4,
    /// 1 day
    D1,
    /// 1 week
    W1,
}

impl Timeframe {
    /// Get minutes for this timeframe
    pub fn minutes(&self) -> u32 {
        match self {
            Timeframe::M1 => 1,
            Timeframe::M5 => 5,
            Timeframe::M15 => 15,
            Timeframe::M30 => 30,
            Timeframe::H1 => 60,
            Timeframe::H4 => 240,
            Timeframe::D1 => 1440,
            Timeframe::W1 => 10080,
        }
    }
    
    /// Get seconds for this timeframe
    pub fn seconds(&self) -> i64 {
        self.minutes() as i64 * 60
    }
    
    /// Get Kraken API interval value
    pub fn kraken_interval(&self) -> u32 {
        self.minutes()
    }
    
    /// Create from minutes
    pub fn from_minutes(minutes: u32) -> Option<Self> {
        match minutes {
            1 => Some(Timeframe::M1),
            5 => Some(Timeframe::M5),
            15 => Some(Timeframe::M15),
            30 => Some(Timeframe::M30),
            60 => Some(Timeframe::H1),
            240 => Some(Timeframe::H4),
            1440 => Some(Timeframe::D1),
            10080 => Some(Timeframe::W1),
            _ => None,
        }
    }
}

impl std::fmt::Display for Timeframe {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Timeframe::M1 => write!(f, "1m"),
            Timeframe::M5 => write!(f, "5m"),
            Timeframe::M15 => write!(f, "15m"),
            Timeframe::M30 => write!(f, "30m"),
            Timeframe::H1 => write!(f, "1H"),
            Timeframe::H4 => write!(f, "4H"),
            Timeframe::D1 => write!(f, "1D"),
            Timeframe::W1 => write!(f, "1W"),
        }
    }
}

/// Trading pair with standard normalization
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct TradingPair {
    pub base: String,
    pub quote: String,
}

impl TradingPair {
    pub fn new(base: &str, quote: &str) -> Self {
        Self {
            base: base.to_uppercase(),
            quote: quote.to_uppercase(),
        }
    }
    
    /// Parse from string like "BTC/USD" or "BTCUSD"
    pub fn parse(s: &str) -> Option<Self> {
        if s.contains('/') {
            let parts: Vec<&str> = s.split('/').collect();
            if parts.len() == 2 {
                return Some(Self::new(parts[0], parts[1]));
            }
        }
        // Try common formats
        for quote in ["USD", "EUR", "GBP", "USDT", "USDC"] {
            if s.to_uppercase().ends_with(quote) {
                let base = &s[..s.len() - quote.len()];
                return Some(Self::new(base, quote));
            }
        }
        None
    }
    
    /// Standard format "BTC/USD"
    pub fn standard(&self) -> String {
        format!("{}/{}", self.base, self.quote)
    }
    
    /// Kraken format (XBT for BTC)
    pub fn kraken_format(&self) -> String {
        let base = match self.base.as_str() {
            "BTC" => "XBT",
            other => other,
        };
        format!("{}{}", base, self.quote)
    }
    
    /// Kraken API pair format for REST endpoints
    pub fn kraken_api_pair(&self) -> String {
        let base = match self.base.as_str() {
            "BTC" => "XXBT",
            "ETH" => "XETH",
            "SOL" => "SOL",
            other => other,
        };
        let quote = match self.quote.as_str() {
            "USD" => "ZUSD",
            "EUR" => "ZEUR",
            other => other,
        };
        format!("{}{}", base, quote)
    }
}

impl std::fmt::Display for TradingPair {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}/{}", self.base, self.quote)
    }
}

/// Data fetch request
#[derive(Debug, Clone)]
pub struct DataRequest {
    pub pair: TradingPair,
    pub timeframe: Timeframe,
    pub start: Option<DateTime<Utc>>,
    pub end: Option<DateTime<Utc>>,
    pub limit: Option<usize>,
}

impl DataRequest {
    pub fn new(pair: TradingPair, timeframe: Timeframe) -> Self {
        Self {
            pair,
            timeframe,
            start: None,
            end: None,
            limit: None,
        }
    }
    
    pub fn with_start(mut self, start: DateTime<Utc>) -> Self {
        self.start = Some(start);
        self
    }
    
    pub fn with_end(mut self, end: DateTime<Utc>) -> Self {
        self.end = Some(end);
        self
    }
    
    pub fn with_limit(mut self, limit: usize) -> Self {
        self.limit = Some(limit);
        self
    }
}

/// Statistics for a dataset
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DataStats {
    pub pair: String,
    pub timeframe: String,
    pub count: usize,
    pub start_time: i64,
    pub end_time: i64,
    pub gaps: Vec<(i64, i64)>,  // (start, end) of gaps
    pub mean_return: f64,
    pub std_return: f64,
    pub min_price: f64,
    pub max_price: f64,
}

impl DataStats {
    /// Calculate stats from candles
    pub fn from_candles(pair: &str, timeframe: Timeframe, candles: &[Candle]) -> Self {
        let mut stats = Self {
            pair: pair.to_string(),
            timeframe: timeframe.to_string(),
            count: candles.len(),
            start_time: candles.first().map(|c| c.timestamp).unwrap_or(0),
            end_time: candles.last().map(|c| c.timestamp).unwrap_or(0),
            gaps: Vec::new(),
            mean_return: 0.0,
            std_return: 0.0,
            min_price: f64::MAX,
            max_price: f64::MIN,
        };
        
        if candles.is_empty() {
            return stats;
        }
        
        let mut returns = Vec::new();
        let expected_interval = timeframe.seconds();
        
        for i in 0..candles.len() {
            let c = &candles[i];
            stats.min_price = stats.min_price.min(c.low);
            stats.max_price = stats.max_price.max(c.high);
            
            if i > 0 {
                returns.push(c.log_return(candles[i - 1].close));
                
                // Check for gaps
                let expected_time = candles[i - 1].timestamp + expected_interval;
                if c.timestamp > expected_time + expected_interval {
                    stats.gaps.push((candles[i - 1].timestamp, c.timestamp));
                }
            }
        }
        
        if !returns.is_empty() {
            stats.mean_return = returns.iter().sum::<f64>() / returns.len() as f64;
            let variance: f64 = returns.iter()
                .map(|r| (r - stats.mean_return).powi(2))
                .sum::<f64>() / returns.len() as f64;
            stats.std_return = variance.sqrt();
        }
        
        stats
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_candle_calculations() {
        let candle = Candle::new(1000, 100.0, 110.0, 95.0, 105.0, 1000.0);
        
        assert!(candle.is_bullish());
        assert!(!candle.is_bearish());
        assert!((candle.typical_price() - 103.333).abs() < 0.01);
    }
    
    #[test]
    fn test_trading_pair_parsing() {
        let pair = TradingPair::parse("BTC/USD").unwrap();
        assert_eq!(pair.base, "BTC");
        assert_eq!(pair.quote, "USD");
        assert_eq!(pair.kraken_format(), "XBTUSD");
    }
    
    #[test]
    fn test_timeframe() {
        assert_eq!(Timeframe::M15.minutes(), 15);
        assert_eq!(Timeframe::H1.seconds(), 3600);
        assert_eq!(Timeframe::from_minutes(60), Some(Timeframe::H1));
    }
}
