//! Data Storage
//!
//! Local caching and storage of OHLCV data in CSV and binary formats.

use super::types::{Candle, DataStats, Timeframe, TradingPair};
use chrono::{TimeZone, Utc};
use serde::{Deserialize, Serialize};
use std::fs::{self, File};
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::{Path, PathBuf};
use thiserror::Error;
use tracing::{debug, info, warn};

/// Storage errors
#[derive(Error, Debug)]
pub enum StorageError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    
    #[error("Parse error: {0}")]
    Parse(String),
    
    #[error("Data not found: {0}")]
    NotFound(String),
    
    #[error("Serialization error: {0}")]
    Serialization(String),
}

/// Configuration for data storage
#[derive(Debug, Clone)]
pub struct StorageConfig {
    /// Root directory for data files
    pub data_dir: PathBuf,
    /// Whether to compress data
    pub compress: bool,
}

impl Default for StorageConfig {
    fn default() -> Self {
        Self {
            data_dir: PathBuf::from("./data/ohlc"),
            compress: false,
        }
    }
}

/// Local data storage and caching
pub struct DataStorage {
    config: StorageConfig,
}

impl DataStorage {
    /// Create new storage with default config
    pub fn new() -> Self {
        Self::with_config(StorageConfig::default())
    }
    
    /// Create with custom config
    pub fn with_config(config: StorageConfig) -> Self {
        // Ensure data directory exists
        if let Err(e) = fs::create_dir_all(&config.data_dir) {
            warn!("Failed to create data directory: {}", e);
        }
        Self { config }
    }
    
    /// Create with specific data directory
    pub fn with_data_dir(data_dir: impl Into<PathBuf>) -> Self {
        Self::with_config(StorageConfig {
            data_dir: data_dir.into(),
            ..Default::default()
        })
    }
    
    /// Save candles to CSV file
    pub fn save_csv(&self, pair: &TradingPair, timeframe: Timeframe, candles: &[Candle]) -> Result<PathBuf, StorageError> {
        let path = self.get_csv_path(pair, timeframe);
        
        // Ensure parent directory exists
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }
        
        let file = File::create(&path)?;
        let mut writer = BufWriter::new(file);
        
        // Write header
        writeln!(writer, "timestamp,open,high,low,close,volume")?;
        
        // Write data
        for candle in candles {
            writeln!(
                writer,
                "{},{},{},{},{},{}",
                candle.timestamp,
                candle.open,
                candle.high,
                candle.low,
                candle.close,
                candle.volume
            )?;
        }
        
        writer.flush()?;
        
        info!("Saved {} candles to {:?}", candles.len(), path);
        Ok(path)
    }
    
    /// Load candles from CSV file
    pub fn load_csv(&self, pair: &TradingPair, timeframe: Timeframe) -> Result<Vec<Candle>, StorageError> {
        let path = self.get_csv_path(pair, timeframe);
        
        if !path.exists() {
            return Err(StorageError::NotFound(format!("{:?}", path)));
        }
        
        let file = File::open(&path)?;
        let reader = BufReader::new(file);
        let mut candles = Vec::new();
        
        for (i, line) in reader.lines().enumerate() {
            let line = line?;
            
            // Skip header
            if i == 0 && line.starts_with("timestamp") {
                continue;
            }
            
            let parts: Vec<&str> = line.split(',').collect();
            if parts.len() < 6 {
                continue;
            }
            
            let candle = Candle {
                timestamp: parts[0].parse().map_err(|e| StorageError::Parse(format!("timestamp: {}", e)))?,
                open: parts[1].parse().map_err(|e| StorageError::Parse(format!("open: {}", e)))?,
                high: parts[2].parse().map_err(|e| StorageError::Parse(format!("high: {}", e)))?,
                low: parts[3].parse().map_err(|e| StorageError::Parse(format!("low: {}", e)))?,
                close: parts[4].parse().map_err(|e| StorageError::Parse(format!("close: {}", e)))?,
                volume: parts[5].parse().map_err(|e| StorageError::Parse(format!("volume: {}", e)))?,
            };
            candles.push(candle);
        }
        
        // Sort by timestamp
        candles.sort_by_key(|c| c.timestamp);
        
        debug!("Loaded {} candles from {:?}", candles.len(), path);
        Ok(candles)
    }
    
    /// Save candles to binary format (faster for large datasets)
    pub fn save_binary(&self, pair: &TradingPair, timeframe: Timeframe, candles: &[Candle]) -> Result<PathBuf, StorageError> {
        let path = self.get_binary_path(pair, timeframe);
        
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }
        
        let file = File::create(&path)?;
        let writer = BufWriter::new(file);
        
        bincode::serialize_into(writer, candles)
            .map_err(|e| StorageError::Serialization(e.to_string()))?;
        
        info!("Saved {} candles to binary {:?}", candles.len(), path);
        Ok(path)
    }
    
    /// Load candles from binary format
    pub fn load_binary(&self, pair: &TradingPair, timeframe: Timeframe) -> Result<Vec<Candle>, StorageError> {
        let path = self.get_binary_path(pair, timeframe);
        
        if !path.exists() {
            return Err(StorageError::NotFound(format!("{:?}", path)));
        }
        
        let file = File::open(&path)?;
        let reader = BufReader::new(file);
        
        let candles: Vec<Candle> = bincode::deserialize_from(reader)
            .map_err(|e| StorageError::Serialization(e.to_string()))?;
        
        debug!("Loaded {} candles from binary {:?}", candles.len(), path);
        Ok(candles)
    }
    
    /// Check if data exists for a pair/timeframe
    pub fn exists(&self, pair: &TradingPair, timeframe: Timeframe) -> bool {
        self.get_csv_path(pair, timeframe).exists() || 
        self.get_binary_path(pair, timeframe).exists()
    }
    
    /// Load candles, preferring binary if available
    pub fn load(&self, pair: &TradingPair, timeframe: Timeframe) -> Result<Vec<Candle>, StorageError> {
        // Try binary first (faster)
        if let Ok(candles) = self.load_binary(pair, timeframe) {
            return Ok(candles);
        }
        // Fall back to CSV
        self.load_csv(pair, timeframe)
    }
    
    /// Get stats for stored data
    pub fn get_stats(&self, pair: &TradingPair, timeframe: Timeframe) -> Result<DataStats, StorageError> {
        let candles = self.load(pair, timeframe)?;
        Ok(DataStats::from_candles(&pair.standard(), timeframe, &candles))
    }
    
    /// List all available data
    pub fn list_available(&self) -> Result<Vec<(String, String, usize)>, StorageError> {
        let mut available = Vec::new();
        
        if !self.config.data_dir.exists() {
            return Ok(available);
        }
        
        for entry in fs::read_dir(&self.config.data_dir)? {
            let entry = entry?;
            let path = entry.path();
            
            if path.is_file() && path.extension().map(|e| e == "csv").unwrap_or(false) {
                if let Some(stem) = path.file_stem().and_then(|s| s.to_str()) {
                    // Parse filename: BTC_USD_15m.csv
                    let parts: Vec<&str> = stem.split('_').collect();
                    if parts.len() >= 3 {
                        let pair = format!("{}/{}", parts[0], parts[1]);
                        let timeframe = parts[2].to_string();
                        
                        // Count lines
                        let count = BufReader::new(File::open(&path)?)
                            .lines()
                            .count()
                            .saturating_sub(1);  // Minus header
                        
                        available.push((pair, timeframe, count));
                    }
                }
            }
        }
        
        Ok(available)
    }
    
    /// Merge new candles with existing data
    pub fn merge_and_save(
        &self,
        pair: &TradingPair,
        timeframe: Timeframe,
        new_candles: Vec<Candle>,
    ) -> Result<usize, StorageError> {
        let mut all_candles = match self.load(pair, timeframe) {
            Ok(existing) => existing,
            Err(_) => Vec::new(),
        };
        
        // Add new candles
        all_candles.extend(new_candles);
        
        // Sort and deduplicate
        all_candles.sort_by_key(|c| c.timestamp);
        all_candles.dedup_by_key(|c| c.timestamp);
        
        let count = all_candles.len();
        
        // Save both formats
        self.save_csv(pair, timeframe, &all_candles)?;
        
        Ok(count)
    }
    
    /// Get file path for CSV
    fn get_csv_path(&self, pair: &TradingPair, timeframe: Timeframe) -> PathBuf {
        self.config.data_dir.join(format!(
            "{}_{}_{}m.csv",
            pair.base,
            pair.quote,
            timeframe.minutes()
        ))
    }
    
    /// Get file path for binary
    fn get_binary_path(&self, pair: &TradingPair, timeframe: Timeframe) -> PathBuf {
        self.config.data_dir.join(format!(
            "{}_{}_{}m.bin",
            pair.base,
            pair.quote,
            timeframe.minutes()
        ))
    }
    
    /// Delete data for a pair/timeframe
    pub fn delete(&self, pair: &TradingPair, timeframe: Timeframe) -> Result<(), StorageError> {
        let csv_path = self.get_csv_path(pair, timeframe);
        let bin_path = self.get_binary_path(pair, timeframe);
        
        if csv_path.exists() {
            fs::remove_file(csv_path)?;
        }
        if bin_path.exists() {
            fs::remove_file(bin_path)?;
        }
        
        Ok(())
    }
    
    /// Filter candles by date range
    pub fn filter_by_date_range(
        candles: &[Candle],
        start: chrono::DateTime<Utc>,
        end: chrono::DateTime<Utc>,
    ) -> Vec<Candle> {
        let start_ts = start.timestamp();
        let end_ts = end.timestamp();
        
        candles
            .iter()
            .filter(|c| c.timestamp >= start_ts && c.timestamp <= end_ts)
            .cloned()
            .collect()
    }
}

impl Default for DataStorage {
    fn default() -> Self {
        Self::new()
    }
}

// Add bincode dependency for binary serialization
// Note: This requires adding bincode = "1.3" to Cargo.toml

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;
    
    fn test_candles() -> Vec<Candle> {
        vec![
            Candle::new(1000, 100.0, 105.0, 95.0, 102.0, 1000.0),
            Candle::new(1060, 102.0, 108.0, 100.0, 106.0, 1100.0),
            Candle::new(1120, 106.0, 110.0, 104.0, 108.0, 1200.0),
        ]
    }
    
    #[test]
    fn test_csv_roundtrip() {
        let temp_dir = TempDir::new().unwrap();
        let storage = DataStorage::with_data_dir(temp_dir.path());
        let pair = TradingPair::new("BTC", "USD");
        let timeframe = Timeframe::M1;
        let candles = test_candles();
        
        // Save
        storage.save_csv(&pair, timeframe, &candles).unwrap();
        
        // Load
        let loaded = storage.load_csv(&pair, timeframe).unwrap();
        
        assert_eq!(loaded.len(), candles.len());
        assert_eq!(loaded[0].timestamp, candles[0].timestamp);
        assert!((loaded[0].close - candles[0].close).abs() < 0.001);
    }
    
    #[test]
    fn test_list_available() {
        let temp_dir = TempDir::new().unwrap();
        let storage = DataStorage::with_data_dir(temp_dir.path());
        
        let pair = TradingPair::new("BTC", "USD");
        storage.save_csv(&pair, Timeframe::M15, &test_candles()).unwrap();
        
        let available = storage.list_available().unwrap();
        assert_eq!(available.len(), 1);
        assert_eq!(available[0].0, "BTC/USD");
    }
}
