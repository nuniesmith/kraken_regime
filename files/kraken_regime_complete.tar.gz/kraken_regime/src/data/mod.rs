//! Data Module
//!
//! Handles fetching, storing, and managing OHLCV data from Kraken.

pub mod fetcher;
pub mod storage;
pub mod types;

pub use fetcher::KrakenDataFetcher;
pub use storage::DataStorage;
pub use types::*;
