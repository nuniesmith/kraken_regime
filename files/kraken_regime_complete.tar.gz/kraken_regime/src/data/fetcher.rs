//! Kraken Data Fetcher
//!
//! Fetches historical OHLCV data from Kraken's public REST API.

use super::types::{Candle, DataRequest, Timeframe, TradingPair};
use chrono::{Duration, Utc};
use reqwest::Client;
use serde::Deserialize;
use std::collections::HashMap;
use thiserror::Error;
use tokio::time::sleep;
use tracing::{debug, info, warn};

/// Errors that can occur during data fetching
#[derive(Error, Debug)]
pub enum FetchError {
    #[error("HTTP request failed: {0}")]
    Http(#[from] reqwest::Error),
    
    #[error("API error: {0}")]
    Api(String),
    
    #[error("Parse error: {0}")]
    Parse(String),
    
    #[error("Rate limited, retry after {0} seconds")]
    RateLimited(u64),
    
    #[error("No data available for {pair} at {timeframe}")]
    NoData { pair: String, timeframe: String },
}

/// Kraken API response for OHLC endpoint
#[derive(Debug, Deserialize)]
struct KrakenOhlcResponse {
    error: Vec<String>,
    result: Option<HashMap<String, serde_json::Value>>,
}

/// Configuration for the data fetcher
#[derive(Debug, Clone)]
pub struct FetcherConfig {
    /// Base URL for Kraken API
    pub base_url: String,
    /// Maximum retries on failure
    pub max_retries: u32,
    /// Delay between requests (ms) to avoid rate limiting
    pub request_delay_ms: u64,
    /// Maximum candles per request (Kraken limit is 720)
    pub max_candles_per_request: usize,
}

impl Default for FetcherConfig {
    fn default() -> Self {
        Self {
            base_url: "https://api.kraken.com".to_string(),
            max_retries: 3,
            request_delay_ms: 1000,  // 1 second between requests
            max_candles_per_request: 720,
        }
    }
}

/// Fetches historical data from Kraken
pub struct KrakenDataFetcher {
    client: Client,
    config: FetcherConfig,
}

impl KrakenDataFetcher {
    /// Create new data fetcher with default config
    pub fn new() -> Self {
        Self::with_config(FetcherConfig::default())
    }
    
    /// Create with custom config
    pub fn with_config(config: FetcherConfig) -> Self {
        let client = Client::builder()
            .timeout(std::time::Duration::from_secs(30))
            .build()
            .expect("Failed to create HTTP client");
        
        Self { client, config }
    }
    
    /// Fetch OHLC data for a single request
    pub async fn fetch(&self, request: &DataRequest) -> Result<Vec<Candle>, FetchError> {
        let pair = &request.pair;
        let timeframe = request.timeframe;
        
        // Build URL
        let url = format!(
            "{}/0/public/OHLC?pair={}&interval={}",
            self.config.base_url,
            pair.kraken_format(),
            timeframe.kraken_interval()
        );
        
        // Add since parameter if start time specified
        let url = if let Some(start) = request.start {
            format!("{}&since={}", url, start.timestamp())
        } else {
            url
        };
        
        debug!("Fetching OHLC from: {}", url);
        
        // Make request with retries
        let mut last_error = None;
        for attempt in 0..self.config.max_retries {
            if attempt > 0 {
                let delay = self.config.request_delay_ms * (attempt as u64 + 1);
                warn!("Retry {} after {}ms", attempt + 1, delay);
                sleep(std::time::Duration::from_millis(delay)).await;
            }
            
            match self.make_request(&url).await {
                Ok(candles) => return Ok(candles),
                Err(e) => {
                    warn!("Request failed: {}", e);
                    last_error = Some(e);
                }
            }
        }
        
        Err(last_error.unwrap_or(FetchError::Api("Max retries exceeded".to_string())))
    }
    
    /// Fetch all historical data for a pair, paginating automatically
    pub async fn fetch_all(
        &self,
        pair: &TradingPair,
        timeframe: Timeframe,
        days: u32,
    ) -> Result<Vec<Candle>, FetchError> {
        let end = Utc::now();
        let start = end - Duration::days(days as i64);
        
        info!(
            "Fetching {} {} data from {} to {}",
            pair.standard(),
            timeframe,
            start.format("%Y-%m-%d"),
            end.format("%Y-%m-%d")
        );
        
        let mut all_candles = Vec::new();
        let mut current_since = start.timestamp();
        let end_timestamp = end.timestamp();
        
        loop {
            let request = DataRequest::new(pair.clone(), timeframe)
                .with_start(chrono::TimeZone::timestamp_opt(&Utc, current_since, 0).unwrap());
            
            // Respect rate limits
            sleep(std::time::Duration::from_millis(self.config.request_delay_ms)).await;
            
            let candles = self.fetch(&request).await?;
            
            if candles.is_empty() {
                break;
            }
            
            let fetched_count = candles.len();
            let last_timestamp = candles.last().map(|c| c.timestamp).unwrap_or(current_since);
            
            // Filter to only include candles after our current position
            let new_candles: Vec<Candle> = candles
                .into_iter()
                .filter(|c| c.timestamp >= current_since && c.timestamp <= end_timestamp)
                .collect();
            
            if new_candles.is_empty() {
                break;
            }
            
            all_candles.extend(new_candles);
            
            // Move forward
            current_since = last_timestamp + 1;
            
            info!(
                "Fetched {} candles, total: {}, up to {}",
                fetched_count,
                all_candles.len(),
                chrono::TimeZone::timestamp_opt(&Utc, last_timestamp, 0).unwrap().format("%Y-%m-%d %H:%M")
            );
            
            // Check if we're done
            if last_timestamp >= end_timestamp || fetched_count < self.config.max_candles_per_request {
                break;
            }
        }
        
        // Sort and deduplicate
        all_candles.sort_by_key(|c| c.timestamp);
        all_candles.dedup_by_key(|c| c.timestamp);
        
        info!(
            "Fetched {} total candles for {} {}",
            all_candles.len(),
            pair.standard(),
            timeframe
        );
        
        Ok(all_candles)
    }
    
    /// Make a single HTTP request
    async fn make_request(&self, url: &str) -> Result<Vec<Candle>, FetchError> {
        let response = self.client.get(url).send().await?;
        
        // Check for rate limiting
        if response.status().as_u16() == 429 {
            let retry_after = response
                .headers()
                .get("Retry-After")
                .and_then(|v| v.to_str().ok())
                .and_then(|v| v.parse().ok())
                .unwrap_or(60);
            return Err(FetchError::RateLimited(retry_after));
        }
        
        let data: KrakenOhlcResponse = response.json().await?;
        
        // Check for API errors
        if !data.error.is_empty() {
            return Err(FetchError::Api(data.error.join(", ")));
        }
        
        // Parse candles
        let result = data.result.ok_or(FetchError::Parse("No result in response".to_string()))?;
        
        // Find the OHLC data (skip "last" key)
        for (key, value) in result.iter() {
            if key == "last" {
                continue;
            }
            
            if let Some(arr) = value.as_array() {
                return self.parse_candles(arr);
            }
        }
        
        Err(FetchError::Parse("No OHLC data found in response".to_string()))
    }
    
    /// Parse Kraken OHLC array format
    fn parse_candles(&self, arr: &[serde_json::Value]) -> Result<Vec<Candle>, FetchError> {
        let mut candles = Vec::new();
        
        for item in arr {
            if let Some(ohlc) = item.as_array() {
                // Format: [time, open, high, low, close, vwap, volume, count]
                if ohlc.len() >= 7 {
                    let candle = Candle {
                        timestamp: ohlc[0].as_i64().unwrap_or(0),
                        open: self.parse_price(&ohlc[1])?,
                        high: self.parse_price(&ohlc[2])?,
                        low: self.parse_price(&ohlc[3])?,
                        close: self.parse_price(&ohlc[4])?,
                        volume: self.parse_price(&ohlc[6])?,
                    };
                    candles.push(candle);
                }
            }
        }
        
        Ok(candles)
    }
    
    /// Parse price from Kraken format (can be string or number)
    fn parse_price(&self, value: &serde_json::Value) -> Result<f64, FetchError> {
        if let Some(s) = value.as_str() {
            s.parse().map_err(|_| FetchError::Parse(format!("Invalid price: {}", s)))
        } else if let Some(n) = value.as_f64() {
            Ok(n)
        } else {
            Err(FetchError::Parse(format!("Invalid price value: {:?}", value)))
        }
    }
    
    /// Get available trading pairs from Kraken
    pub async fn get_pairs(&self) -> Result<Vec<String>, FetchError> {
        let url = format!("{}/0/public/AssetPairs", self.config.base_url);
        let response = self.client.get(&url).send().await?;
        
        #[derive(Deserialize)]
        struct Response {
            error: Vec<String>,
            result: Option<HashMap<String, serde_json::Value>>,
        }
        
        let data: Response = response.json().await?;
        
        if !data.error.is_empty() {
            return Err(FetchError::Api(data.error.join(", ")));
        }
        
        let result = data.result.ok_or(FetchError::Parse("No result".to_string()))?;
        let pairs: Vec<String> = result.keys().cloned().collect();
        
        Ok(pairs)
    }
    
    /// Fetch ticker for current price
    pub async fn get_ticker(&self, pair: &TradingPair) -> Result<f64, FetchError> {
        let url = format!(
            "{}/0/public/Ticker?pair={}",
            self.config.base_url,
            pair.kraken_format()
        );
        
        let response = self.client.get(&url).send().await?;
        
        #[derive(Deserialize)]
        struct Response {
            error: Vec<String>,
            result: Option<HashMap<String, TickerInfo>>,
        }
        
        #[derive(Deserialize)]
        struct TickerInfo {
            c: Vec<String>,  // last trade [price, volume]
        }
        
        let data: Response = response.json().await?;
        
        if !data.error.is_empty() {
            return Err(FetchError::Api(data.error.join(", ")));
        }
        
        let result = data.result.ok_or(FetchError::Parse("No result".to_string()))?;
        
        for (_, ticker) in result {
            if let Some(price_str) = ticker.c.first() {
                return price_str.parse()
                    .map_err(|_| FetchError::Parse("Invalid price".to_string()));
            }
        }
        
        Err(FetchError::Parse("No ticker data".to_string()))
    }
}

impl Default for KrakenDataFetcher {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_config_defaults() {
        let config = FetcherConfig::default();
        assert_eq!(config.max_candles_per_request, 720);
        assert_eq!(config.max_retries, 3);
    }
    
    // Integration tests would go here, but they require network access
    // Run with: cargo test -- --ignored
    
    #[tokio::test]
    #[ignore = "requires network"]
    async fn test_fetch_btc() {
        let fetcher = KrakenDataFetcher::new();
        let pair = TradingPair::new("BTC", "USD");
        let request = DataRequest::new(pair, Timeframe::H1).with_limit(100);
        
        let candles = fetcher.fetch(&request).await.expect("Failed to fetch");
        assert!(!candles.is_empty());
        println!("Fetched {} BTC/USD candles", candles.len());
    }
}
