//! Kraken Regime-Aware Trading Bot
//!
//! A complete algorithmic trading system with:
//! - **Regime Detection** - Indicators, HMM, and Ensemble methods
//! - **Strategy Routing** - Automatic strategy switching based on market conditions
//! - **Data Management** - Fetch and store historical OHLCV data
//! - **Backtesting** - Realistic simulation with fees/slippage
//! - **Walk-Forward Testing** - Out-of-sample validation
//!
//! ## Quick Start
//!
//! ```rust,no_run
//! use kraken_regime::prelude::*;
//!
//! #[tokio::main]
//! async fn main() -> Result<(), Box<dyn std::error::Error>> {
//!     // Fetch historical data
//!     let fetcher = KrakenDataFetcher::new();
//!     let pair = TradingPair::new("BTC", "USD");
//!     let candles = fetcher.fetch_all(&pair, Timeframe::M15, 30).await?;
//!
//!     // Run backtest with realistic costs
//!     let config = BacktestConfig::default();
//!     let mut backtester = Backtester::new(config);
//!     let result = backtester.run("BTC/USD", &candles);
//!     
//!     result.metrics.print_summary();
//!     Ok(())
//! }
//! ```

// Core modules
pub mod regime;
pub mod strategy;
pub mod integration;
pub mod data;
pub mod backtest;

// Tests module (only compiled with tests)
#[cfg(test)]
mod tests;

// Re-exports for convenience
pub use regime::{
    MarketRegime,
    TrendDirection,
    RegimeConfig,
    RegimeConfidence,
    RegimeDetector,
    RecommendedStrategy,
    HMMRegimeDetector,
    HMMConfig,
    EnsembleRegimeDetector,
    EnsembleConfig,
};

pub use strategy::{
    mean_reversion::{MeanReversionStrategy, MeanReversionConfig, Signal},
    router::{StrategyRouter, StrategyRouterConfig, RoutedSignal, ActiveStrategy},
    EnhancedRouter,
    EnhancedRouterConfig,
    DetectionMethod,
};

pub use integration::{
    KrakenRegimeTrader,
    KrakenIntegrationConfig,
    Candle,
    TradeAction,
    TradeType,
};

pub use data::{
    KrakenDataFetcher,
    DataStorage,
    Timeframe,
    TradingPair,
    DataStats,
};

pub use backtest::{
    Backtester,
    BacktestConfig,
    BacktestResult,
    PerformanceMetrics,
    TradingCosts,
    SlippageModel,
    WalkForwardAnalysis,
    WalkForwardConfig,
    WalkForwardResult,
};

/// Version information
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Prelude for common imports
pub mod prelude {
    pub use crate::{
        // Regime
        MarketRegime,
        RegimeDetector,
        HMMRegimeDetector,
        EnsembleRegimeDetector,
        // Strategy
        StrategyRouter,
        EnhancedRouter,
        Signal,
        // Integration
        KrakenRegimeTrader,
        KrakenIntegrationConfig,
        Candle,
        TradeAction,
        // Data
        KrakenDataFetcher,
        DataStorage,
        Timeframe,
        TradingPair,
        // Backtesting
        Backtester,
        BacktestConfig,
        BacktestResult,
        PerformanceMetrics,
        TradingCosts,
        WalkForwardAnalysis,
        WalkForwardConfig,
    };
}
