//! Walk-Forward Analysis
//!
//! Implements walk-forward optimization and testing:
//! 1. Split data into training/testing windows
//! 2. Optimize parameters on training data
//! 3. Test on out-of-sample data
//! 4. Roll forward and repeat
//!
//! This prevents overfitting and gives realistic performance estimates.

use super::engine::{Backtester, BacktestConfig, BacktestResult};
use super::metrics::PerformanceMetrics;
use crate::data::types::Candle;
use crate::strategy::router::StrategyRouterConfig;
use crate::regime::RegimeConfig;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use tracing::{info, warn};

/// Walk-forward configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WalkForwardConfig {
    /// Training window size (in bars)
    pub train_size: usize,
    /// Testing window size (in bars)
    pub test_size: usize,
    /// Step size for rolling (usually same as test_size)
    pub step_size: usize,
    /// Minimum data required before first window
    pub warmup_bars: usize,
    /// Number of optimization trials per window
    pub optimization_trials: usize,
    /// Metric to optimize for
    pub optimization_target: OptimizationTarget,
}

impl Default for WalkForwardConfig {
    fn default() -> Self {
        Self {
            train_size: 4 * 96 * 30,  // 30 days at 15-min bars
            test_size: 96 * 7,        // 7 days
            step_size: 96 * 7,        // Roll forward 7 days
            warmup_bars: 200,         // Warmup period
            optimization_trials: 50,
            optimization_target: OptimizationTarget::SharpeRatio,
        }
    }
}

/// What to optimize for
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum OptimizationTarget {
    TotalReturn,
    SharpeRatio,
    SortinoRatio,
    CalmarRatio,
    ProfitFactor,
    WinRate,
}

impl OptimizationTarget {
    /// Get score from metrics (higher is better)
    pub fn score(&self, metrics: &PerformanceMetrics) -> f64 {
        match self {
            OptimizationTarget::TotalReturn => metrics.total_return_pct,
            OptimizationTarget::SharpeRatio => metrics.sharpe_ratio,
            OptimizationTarget::SortinoRatio => metrics.sortino_ratio,
            OptimizationTarget::CalmarRatio => metrics.calmar_ratio,
            OptimizationTarget::ProfitFactor => metrics.profit_factor,
            OptimizationTarget::WinRate => metrics.win_rate,
        }
    }
}

/// Result from a single walk-forward window
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WindowResult {
    pub window_id: usize,
    pub train_start: i64,
    pub train_end: i64,
    pub test_start: i64,
    pub test_end: i64,
    pub train_metrics: PerformanceMetrics,
    pub test_metrics: PerformanceMetrics,
    pub optimized_params: OptimizedParams,
}

/// Optimized parameters from training
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimizedParams {
    pub adx_trending_threshold: f64,
    pub adx_ranging_threshold: f64,
    pub bb_period: usize,
    pub bb_std_dev: f64,
    pub mean_reversion_entry_threshold: f64,
    pub risk_per_trade: f64,
}

impl Default for OptimizedParams {
    fn default() -> Self {
        Self {
            adx_trending_threshold: 25.0,
            adx_ranging_threshold: 20.0,
            bb_period: 20,
            bb_std_dev: 2.0,
            mean_reversion_entry_threshold: 0.05,
            risk_per_trade: 0.01,
        }
    }
}

/// Complete walk-forward analysis result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WalkForwardResult {
    pub config: WalkForwardConfig,
    pub windows: Vec<WindowResult>,
    pub combined_test_metrics: PerformanceMetrics,
    pub out_of_sample_return: f64,
    pub in_sample_return: f64,
    pub efficiency_ratio: f64,  // OOS return / IS return
    pub consistency_score: f64, // % of windows that were profitable
}

impl WalkForwardResult {
    /// Print summary
    pub fn print_summary(&self) {
        println!("\n╔══════════════════════════════════════════════════════════════╗");
        println!("║              WALK-FORWARD ANALYSIS RESULTS                   ║");
        println!("╠══════════════════════════════════════════════════════════════╣");
        
        println!("║ Windows Analyzed:   {:>6}                                   ║", self.windows.len());
        println!("║ In-Sample Return:   {:>10.2}%                              ║", self.in_sample_return);
        println!("║ Out-of-Sample:      {:>10.2}%                              ║", self.out_of_sample_return);
        println!("║ Efficiency Ratio:   {:>10.2}                               ║", self.efficiency_ratio);
        println!("║ Consistency:        {:>10.1}% windows profitable           ║", self.consistency_score);
        
        println!("╠══════════════════════════════════════════════════════════════╣");
        println!("║ OUT-OF-SAMPLE COMBINED METRICS                               ║");
        println!("║   Sharpe Ratio:     {:>10.2}                               ║", self.combined_test_metrics.sharpe_ratio);
        println!("║   Max Drawdown:     {:>10.2}%                              ║", self.combined_test_metrics.max_drawdown_pct);
        println!("║   Win Rate:         {:>10.1}%                              ║", self.combined_test_metrics.win_rate);
        println!("║   Profit Factor:    {:>10.2}                               ║", self.combined_test_metrics.profit_factor);
        
        println!("╠══════════════════════════════════════════════════════════════╣");
        println!("║ PER-WINDOW BREAKDOWN                                         ║");
        println!("├───────┬────────────┬────────────┬────────────┬──────────────┤");
        println!("│ Win # │ Train Ret% │ Test Ret%  │ Sharpe     │ Status       │");
        println!("├───────┼────────────┼────────────┼────────────┼──────────────┤");
        
        for w in &self.windows {
            let status = if w.test_metrics.total_return_pct > 0.0 { "✓" } else { "✗" };
            println!("│ {:>5} │ {:>10.2} │ {:>10.2} │ {:>10.2} │ {:>12} │",
                w.window_id,
                w.train_metrics.total_return_pct,
                w.test_metrics.total_return_pct,
                w.test_metrics.sharpe_ratio,
                status
            );
        }
        
        println!("└───────┴────────────┴────────────┴────────────┴──────────────┘");
        
        // Interpretation
        println!("\n📊 Interpretation:");
        if self.efficiency_ratio > 0.5 {
            println!("   ✓ Good efficiency ratio - strategy generalizes well");
        } else if self.efficiency_ratio > 0.3 {
            println!("   ⚠ Moderate efficiency - some overfitting may be present");
        } else {
            println!("   ✗ Low efficiency - likely overfitting detected");
        }
        
        if self.consistency_score > 70.0 {
            println!("   ✓ High consistency - strategy performs well across periods");
        } else if self.consistency_score > 50.0 {
            println!("   ⚠ Moderate consistency - performance varies by period");
        } else {
            println!("   ✗ Low consistency - strategy is unreliable");
        }
    }
}

/// Walk-forward analyzer
pub struct WalkForwardAnalysis {
    config: WalkForwardConfig,
    backtest_config: BacktestConfig,
}

impl WalkForwardAnalysis {
    /// Create new walk-forward analysis
    pub fn new(config: WalkForwardConfig, backtest_config: BacktestConfig) -> Self {
        Self {
            config,
            backtest_config,
        }
    }
    
    /// Run walk-forward analysis
    pub fn run(&self, symbol: &str, candles: &[Candle]) -> WalkForwardResult {
        info!("Starting walk-forward analysis with {} candles", candles.len());
        
        let mut windows = Vec::new();
        let total_size = self.config.train_size + self.config.test_size;
        
        if candles.len() < total_size + self.config.warmup_bars {
            warn!("Not enough data for walk-forward analysis");
            return self.empty_result();
        }
        
        let mut window_id = 0;
        let mut pos = self.config.warmup_bars;
        
        // Combined test trades for overall metrics
        let mut all_test_returns: Vec<f64> = Vec::new();
        
        while pos + total_size <= candles.len() {
            window_id += 1;
            
            let train_start = pos;
            let train_end = pos + self.config.train_size;
            let test_start = train_end;
            let test_end = (test_start + self.config.test_size).min(candles.len());
            
            info!(
                "Window {}: Train [{}-{}], Test [{}-{}]",
                window_id, train_start, train_end, test_start, test_end
            );
            
            // Get data slices
            let train_data = &candles[train_start..train_end];
            let test_data = &candles[test_start..test_end];
            
            // Optimize on training data
            let optimized_params = self.optimize(symbol, train_data);
            
            // Run on training data with optimized params
            let train_result = self.run_with_params(symbol, train_data, &optimized_params);
            
            // Run on test data with same params (out-of-sample)
            let test_result = self.run_with_params(symbol, test_data, &optimized_params);
            
            all_test_returns.push(test_result.metrics.total_return_pct);
            
            windows.push(WindowResult {
                window_id,
                train_start: candles[train_start].timestamp,
                train_end: candles[train_end - 1].timestamp,
                test_start: candles[test_start].timestamp,
                test_end: candles[test_end - 1].timestamp,
                train_metrics: train_result.metrics,
                test_metrics: test_result.metrics,
                optimized_params,
            });
            
            pos += self.config.step_size;
        }
        
        // Calculate combined metrics
        let in_sample_return: f64 = windows.iter()
            .map(|w| w.train_metrics.total_return_pct)
            .sum::<f64>() / windows.len() as f64;
        
        let out_of_sample_return: f64 = windows.iter()
            .map(|w| w.test_metrics.total_return_pct)
            .sum::<f64>() / windows.len() as f64;
        
        let profitable_windows = windows.iter()
            .filter(|w| w.test_metrics.total_return_pct > 0.0)
            .count();
        let consistency_score = profitable_windows as f64 / windows.len() as f64 * 100.0;
        
        let efficiency_ratio = if in_sample_return != 0.0 {
            out_of_sample_return / in_sample_return
        } else {
            0.0
        };
        
        // Aggregate test metrics
        let combined_test_metrics = self.aggregate_metrics(&windows);
        
        WalkForwardResult {
            config: self.config.clone(),
            windows,
            combined_test_metrics,
            out_of_sample_return,
            in_sample_return,
            efficiency_ratio,
            consistency_score,
        }
    }
    
    /// Optimize parameters on training data
    fn optimize(&self, symbol: &str, train_data: &[Candle]) -> OptimizedParams {
        let mut best_score = f64::NEG_INFINITY;
        let mut best_params = OptimizedParams::default();
        
        // Parameter ranges to search
        let adx_trending_range = [20.0, 22.0, 25.0, 28.0, 30.0];
        let adx_ranging_range = [15.0, 18.0, 20.0];
        let bb_period_range = [15, 20, 25];
        let bb_std_range = [1.5, 2.0, 2.5];
        let risk_range = [0.005, 0.01, 0.015, 0.02];
        
        let mut trials = 0;
        
        // Grid search (simplified - could use Optuna for real optimization)
        for &adx_trend in &adx_trending_range {
            for &adx_range in &adx_ranging_range {
                if adx_range >= adx_trend {
                    continue;  // Invalid combination
                }
                
                for &bb_period in &bb_period_range {
                    for &bb_std in &bb_std_range {
                        for &risk in &risk_range {
                            if trials >= self.config.optimization_trials {
                                break;
                            }
                            
                            let params = OptimizedParams {
                                adx_trending_threshold: adx_trend,
                                adx_ranging_threshold: adx_range,
                                bb_period,
                                bb_std_dev: bb_std,
                                mean_reversion_entry_threshold: 0.05,
                                risk_per_trade: risk,
                            };
                            
                            let result = self.run_with_params(symbol, train_data, &params);
                            let score = self.config.optimization_target.score(&result.metrics);
                            
                            if score > best_score {
                                best_score = score;
                                best_params = params;
                            }
                            
                            trials += 1;
                        }
                    }
                }
            }
        }
        
        info!("Optimization found best score: {:.4}", best_score);
        best_params
    }
    
    /// Run backtest with specific parameters
    fn run_with_params(
        &self,
        symbol: &str,
        data: &[Candle],
        params: &OptimizedParams,
    ) -> BacktestResult {
        let mut config = self.backtest_config.clone();
        config.risk_per_trade = params.risk_per_trade;
        
        // Update router config
        config.router_config.regime_config.adx_trending_threshold = params.adx_trending_threshold;
        config.router_config.regime_config.adx_ranging_threshold = params.adx_ranging_threshold;
        config.router_config.mean_reversion_config.bb_period = params.bb_period;
        config.router_config.mean_reversion_config.bb_std_dev = params.bb_std_dev;
        config.router_config.mean_reversion_config.entry_threshold = params.mean_reversion_entry_threshold;
        
        let mut backtester = Backtester::new(config);
        backtester.run(symbol, data)
    }
    
    /// Aggregate metrics from all test windows
    fn aggregate_metrics(&self, windows: &[WindowResult]) -> PerformanceMetrics {
        if windows.is_empty() {
            return PerformanceMetrics::empty();
        }
        
        let mut metrics = PerformanceMetrics::empty();
        
        // Average the metrics
        metrics.total_return_pct = windows.iter()
            .map(|w| w.test_metrics.total_return_pct)
            .sum::<f64>() / windows.len() as f64;
        
        metrics.sharpe_ratio = windows.iter()
            .map(|w| w.test_metrics.sharpe_ratio)
            .sum::<f64>() / windows.len() as f64;
        
        metrics.sortino_ratio = windows.iter()
            .map(|w| w.test_metrics.sortino_ratio)
            .sum::<f64>() / windows.len() as f64;
        
        metrics.max_drawdown_pct = windows.iter()
            .map(|w| w.test_metrics.max_drawdown_pct)
            .fold(0.0, f64::max);
        
        metrics.total_trades = windows.iter()
            .map(|w| w.test_metrics.total_trades)
            .sum();
        
        let total_wins: u32 = windows.iter()
            .map(|w| w.test_metrics.winning_trades)
            .sum();
        
        metrics.winning_trades = total_wins;
        metrics.win_rate = if metrics.total_trades > 0 {
            total_wins as f64 / metrics.total_trades as f64 * 100.0
        } else {
            0.0
        };
        
        // Aggregate profit factor
        let total_profit: f64 = windows.iter()
            .flat_map(|w| std::iter::once(w.test_metrics.avg_win * w.test_metrics.winning_trades as f64))
            .sum();
        let total_loss: f64 = windows.iter()
            .flat_map(|w| std::iter::once(w.test_metrics.avg_loss.abs() * w.test_metrics.losing_trades as f64))
            .sum();
        
        metrics.profit_factor = if total_loss > 0.0 { total_profit / total_loss } else { 0.0 };
        
        metrics
    }
    
    /// Empty result for error cases
    fn empty_result(&self) -> WalkForwardResult {
        WalkForwardResult {
            config: self.config.clone(),
            windows: Vec::new(),
            combined_test_metrics: PerformanceMetrics::empty(),
            out_of_sample_return: 0.0,
            in_sample_return: 0.0,
            efficiency_ratio: 0.0,
            consistency_score: 0.0,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    fn generate_test_data(n: usize) -> Vec<Candle> {
        let mut candles = Vec::new();
        let mut price = 50000.0;
        
        for i in 0..n {
            // Add some trend and noise
            let trend = (i as f64 * 0.001).sin() * 100.0;
            let noise = ((i as f64 * 0.1).sin() * 50.0) + ((i as f64 * 0.3).cos() * 30.0);
            price += trend + noise;
            price = price.max(1.0);
            
            candles.push(Candle {
                timestamp: i as i64 * 900,
                open: price - 10.0,
                high: price + 50.0,
                low: price - 50.0,
                close: price,
                volume: 100.0,
            });
        }
        candles
    }
    
    #[test]
    fn test_walk_forward_basic() {
        let wf_config = WalkForwardConfig {
            train_size: 500,
            test_size: 100,
            step_size: 100,
            warmup_bars: 100,
            optimization_trials: 10,
            optimization_target: OptimizationTarget::SharpeRatio,
        };
        
        let bt_config = BacktestConfig::default();
        let wf = WalkForwardAnalysis::new(wf_config, bt_config);
        
        let data = generate_test_data(2000);
        let result = wf.run("BTC/USD", &data);
        
        result.print_summary();
        
        assert!(!result.windows.is_empty());
    }
}
