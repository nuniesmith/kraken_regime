//! Performance Metrics
//!
//! Comprehensive trading performance metrics including:
//! - Return metrics (total, CAGR, etc.)
//! - Risk metrics (Sharpe, Sortino, Max DD)
//! - Trade statistics (win rate, profit factor)

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Complete performance metrics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerformanceMetrics {
    // Return metrics
    pub total_return_pct: f64,
    pub total_return_usd: f64,
    pub cagr: f64,
    pub daily_return_mean: f64,
    pub daily_return_std: f64,
    
    // Risk metrics
    pub sharpe_ratio: f64,
    pub sortino_ratio: f64,
    pub calmar_ratio: f64,
    pub max_drawdown_pct: f64,
    pub max_drawdown_usd: f64,
    pub max_drawdown_duration_days: f64,
    pub avg_drawdown_pct: f64,
    pub ulcer_index: f64,
    
    // Trade statistics
    pub total_trades: u32,
    pub winning_trades: u32,
    pub losing_trades: u32,
    pub win_rate: f64,
    pub profit_factor: f64,
    pub avg_win: f64,
    pub avg_loss: f64,
    pub largest_win: f64,
    pub largest_loss: f64,
    pub avg_trade_duration_hours: f64,
    pub trades_per_day: f64,
    
    // Exposure
    pub time_in_market_pct: f64,
    pub avg_position_size: f64,
    pub max_position_size: f64,
    
    // Costs
    pub total_fees: f64,
    pub total_slippage: f64,
    pub total_costs: f64,
    pub costs_as_pct_of_profit: f64,
    
    // By regime (optional)
    pub regime_metrics: Option<HashMap<String, RegimeMetrics>>,
}

impl PerformanceMetrics {
    /// Create empty metrics
    pub fn empty() -> Self {
        Self {
            total_return_pct: 0.0,
            total_return_usd: 0.0,
            cagr: 0.0,
            daily_return_mean: 0.0,
            daily_return_std: 0.0,
            sharpe_ratio: 0.0,
            sortino_ratio: 0.0,
            calmar_ratio: 0.0,
            max_drawdown_pct: 0.0,
            max_drawdown_usd: 0.0,
            max_drawdown_duration_days: 0.0,
            avg_drawdown_pct: 0.0,
            ulcer_index: 0.0,
            total_trades: 0,
            winning_trades: 0,
            losing_trades: 0,
            win_rate: 0.0,
            profit_factor: 0.0,
            avg_win: 0.0,
            avg_loss: 0.0,
            largest_win: 0.0,
            largest_loss: 0.0,
            avg_trade_duration_hours: 0.0,
            trades_per_day: 0.0,
            time_in_market_pct: 0.0,
            avg_position_size: 0.0,
            max_position_size: 0.0,
            total_fees: 0.0,
            total_slippage: 0.0,
            total_costs: 0.0,
            costs_as_pct_of_profit: 0.0,
            regime_metrics: None,
        }
    }
    
    /// Print formatted summary
    pub fn print_summary(&self) {
        println!("\n╔══════════════════════════════════════════════════════════════╗");
        println!("║                  PERFORMANCE METRICS                         ║");
        println!("╠══════════════════════════════════════════════════════════════╣");
        
        println!("║ RETURNS                                                      ║");
        println!("║   Total Return:       {:>10.2}% (${:>12.2})            ║", 
                 self.total_return_pct, self.total_return_usd);
        println!("║   CAGR:               {:>10.2}%                            ║", self.cagr);
        println!("║   Daily Mean:         {:>10.4}%                            ║", self.daily_return_mean * 100.0);
        println!("║   Daily Std:          {:>10.4}%                            ║", self.daily_return_std * 100.0);
        
        println!("╠══════════════════════════════════════════════════════════════╣");
        println!("║ RISK-ADJUSTED                                                ║");
        println!("║   Sharpe Ratio:       {:>10.2}                              ║", self.sharpe_ratio);
        println!("║   Sortino Ratio:      {:>10.2}                              ║", self.sortino_ratio);
        println!("║   Calmar Ratio:       {:>10.2}                              ║", self.calmar_ratio);
        
        println!("╠══════════════════════════════════════════════════════════════╣");
        println!("║ DRAWDOWN                                                     ║");
        println!("║   Max Drawdown:       {:>10.2}% (${:>12.2})            ║", 
                 self.max_drawdown_pct, self.max_drawdown_usd);
        println!("║   Max DD Duration:    {:>10.1} days                         ║", self.max_drawdown_duration_days);
        println!("║   Avg Drawdown:       {:>10.2}%                            ║", self.avg_drawdown_pct);
        println!("║   Ulcer Index:        {:>10.2}                              ║", self.ulcer_index);
        
        println!("╠══════════════════════════════════════════════════════════════╣");
        println!("║ TRADES                                                       ║");
        println!("║   Total Trades:       {:>10}                              ║", self.total_trades);
        println!("║   Win Rate:           {:>10.1}% ({}/{})                   ║", 
                 self.win_rate, self.winning_trades, self.total_trades);
        println!("║   Profit Factor:      {:>10.2}                              ║", self.profit_factor);
        println!("║   Avg Win:           ${:>10.2}                              ║", self.avg_win);
        println!("║   Avg Loss:          ${:>10.2}                              ║", self.avg_loss);
        println!("║   Largest Win:       ${:>10.2}                              ║", self.largest_win);
        println!("║   Largest Loss:      ${:>10.2}                              ║", self.largest_loss);
        
        println!("╠══════════════════════════════════════════════════════════════╣");
        println!("║ COSTS                                                        ║");
        println!("║   Total Fees:        ${:>10.2}                              ║", self.total_fees);
        println!("║   Total Slippage:    ${:>10.2}                              ║", self.total_slippage);
        println!("║   Costs % of Profit: {:>10.1}%                             ║", self.costs_as_pct_of_profit);
        
        println!("╠══════════════════════════════════════════════════════════════╣");
        println!("║ EXPOSURE                                                     ║");
        println!("║   Time in Market:     {:>10.1}%                             ║", self.time_in_market_pct);
        println!("║   Trades/Day:         {:>10.2}                              ║", self.trades_per_day);
        
        println!("╚══════════════════════════════════════════════════════════════╝");
        
        // Print regime breakdown if available
        if let Some(ref regime_metrics) = self.regime_metrics {
            println!("\n┌──────────────────────────────────────────────────────────────┐");
            println!("│                  BY REGIME BREAKDOWN                         │");
            println!("├─────────────┬────────┬─────────┬──────────┬─────────────────┤");
            println!("│ Regime      │ Trades │ Win Rate│ P/L      │ Profit Factor   │");
            println!("├─────────────┼────────┼─────────┼──────────┼─────────────────┤");
            for (regime, metrics) in regime_metrics {
                println!("│ {:11} │ {:>6} │ {:>6.1}% │ ${:>7.2} │ {:>15.2} │",
                    regime,
                    metrics.trades,
                    metrics.win_rate,
                    metrics.total_pnl,
                    metrics.profit_factor
                );
            }
            println!("└─────────────┴────────┴─────────┴──────────┴─────────────────┘");
        }
    }
    
    /// Check if performance is acceptable
    pub fn is_acceptable(&self, min_sharpe: f64, max_dd: f64) -> bool {
        self.sharpe_ratio >= min_sharpe && self.max_drawdown_pct.abs() <= max_dd
    }
}

/// Metrics for a specific regime
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RegimeMetrics {
    pub regime: String,
    pub trades: u32,
    pub winning_trades: u32,
    pub win_rate: f64,
    pub total_pnl: f64,
    pub avg_pnl: f64,
    pub profit_factor: f64,
    pub bars_in_regime: u32,
}

/// Calculate metrics from equity curve and trades
pub struct MetricsCalculator {
    /// Annualization factor (252 for daily, 365*24 for hourly, etc.)
    pub annualization_factor: f64,
    /// Risk-free rate for Sharpe calculation
    pub risk_free_rate: f64,
}

impl MetricsCalculator {
    /// Create for daily data
    pub fn daily() -> Self {
        Self {
            annualization_factor: 252.0,
            risk_free_rate: 0.05,  // 5% risk-free
        }
    }
    
    /// Create for hourly data
    pub fn hourly() -> Self {
        Self {
            annualization_factor: 252.0 * 24.0,
            risk_free_rate: 0.05,
        }
    }
    
    /// Create for 15-minute data
    pub fn m15() -> Self {
        Self {
            annualization_factor: 252.0 * 24.0 * 4.0,  // 4 periods per hour
            risk_free_rate: 0.05,
        }
    }
    
    /// Calculate Sharpe ratio
    pub fn sharpe_ratio(&self, returns: &[f64]) -> f64 {
        if returns.is_empty() {
            return 0.0;
        }
        
        let mean = returns.iter().sum::<f64>() / returns.len() as f64;
        let variance: f64 = returns.iter()
            .map(|r| (r - mean).powi(2))
            .sum::<f64>() / returns.len() as f64;
        let std = variance.sqrt();
        
        if std == 0.0 {
            return 0.0;
        }
        
        let excess_return = mean - (self.risk_free_rate / self.annualization_factor);
        (excess_return / std) * self.annualization_factor.sqrt()
    }
    
    /// Calculate Sortino ratio (only downside deviation)
    pub fn sortino_ratio(&self, returns: &[f64]) -> f64 {
        if returns.is_empty() {
            return 0.0;
        }
        
        let mean = returns.iter().sum::<f64>() / returns.len() as f64;
        let downside_variance: f64 = returns.iter()
            .filter(|&&r| r < 0.0)
            .map(|r| r.powi(2))
            .sum::<f64>() / returns.len() as f64;
        let downside_std = downside_variance.sqrt();
        
        if downside_std == 0.0 {
            return f64::INFINITY;  // No downside
        }
        
        let excess_return = mean - (self.risk_free_rate / self.annualization_factor);
        (excess_return / downside_std) * self.annualization_factor.sqrt()
    }
    
    /// Calculate maximum drawdown
    pub fn max_drawdown(&self, equity_curve: &[f64]) -> (f64, f64, usize) {
        if equity_curve.is_empty() {
            return (0.0, 0.0, 0);
        }
        
        let mut peak = equity_curve[0];
        let mut max_dd_pct = 0.0;
        let mut max_dd_usd = 0.0;
        let mut dd_start = 0;
        let mut max_dd_duration = 0;
        let mut current_dd_start = 0;
        
        for (i, &equity) in equity_curve.iter().enumerate() {
            if equity > peak {
                peak = equity;
                current_dd_start = i;
            }
            
            let dd_usd = peak - equity;
            let dd_pct = dd_usd / peak * 100.0;
            
            if dd_pct > max_dd_pct {
                max_dd_pct = dd_pct;
                max_dd_usd = dd_usd;
                max_dd_duration = i - current_dd_start;
            }
        }
        
        (max_dd_pct, max_dd_usd, max_dd_duration)
    }
    
    /// Calculate average drawdown
    pub fn avg_drawdown(&self, equity_curve: &[f64]) -> f64 {
        if equity_curve.is_empty() {
            return 0.0;
        }
        
        let mut peak = equity_curve[0];
        let mut total_dd = 0.0;
        let mut count = 0;
        
        for &equity in equity_curve {
            if equity > peak {
                peak = equity;
            }
            let dd = (peak - equity) / peak * 100.0;
            if dd > 0.0 {
                total_dd += dd;
                count += 1;
            }
        }
        
        if count == 0 { 0.0 } else { total_dd / count as f64 }
    }
    
    /// Calculate Ulcer Index (measures pain of drawdowns)
    pub fn ulcer_index(&self, equity_curve: &[f64]) -> f64 {
        if equity_curve.is_empty() {
            return 0.0;
        }
        
        let mut peak = equity_curve[0];
        let mut sum_sq_dd = 0.0;
        
        for &equity in equity_curve {
            if equity > peak {
                peak = equity;
            }
            let dd_pct = (peak - equity) / peak * 100.0;
            sum_sq_dd += dd_pct * dd_pct;
        }
        
        (sum_sq_dd / equity_curve.len() as f64).sqrt()
    }
    
    /// Calculate CAGR
    pub fn cagr(&self, start_value: f64, end_value: f64, periods: usize) -> f64 {
        if periods == 0 || start_value == 0.0 {
            return 0.0;
        }
        
        let years = periods as f64 / self.annualization_factor;
        if years <= 0.0 {
            return 0.0;
        }
        
        ((end_value / start_value).powf(1.0 / years) - 1.0) * 100.0
    }
    
    /// Calculate profit factor
    pub fn profit_factor(wins: &[f64], losses: &[f64]) -> f64 {
        let total_wins: f64 = wins.iter().sum();
        let total_losses: f64 = losses.iter().map(|l| l.abs()).sum();
        
        if total_losses == 0.0 {
            if total_wins > 0.0 { f64::INFINITY } else { 0.0 }
        } else {
            total_wins / total_losses
        }
    }
    
    /// Calculate Calmar ratio (CAGR / Max DD)
    pub fn calmar_ratio(&self, cagr: f64, max_dd: f64) -> f64 {
        if max_dd == 0.0 {
            return 0.0;
        }
        cagr / max_dd.abs()
    }
}

impl Default for MetricsCalculator {
    fn default() -> Self {
        Self::daily()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_sharpe_ratio() {
        let calc = MetricsCalculator::daily();
        
        // Consistent positive returns should have high Sharpe
        let good_returns = vec![0.01, 0.008, 0.012, 0.009, 0.011];
        let sharpe = calc.sharpe_ratio(&good_returns);
        println!("Good returns Sharpe: {:.2}", sharpe);
        assert!(sharpe > 0.0);
        
        // Volatile returns should have lower Sharpe
        let volatile_returns = vec![0.05, -0.04, 0.06, -0.03, 0.02];
        let vol_sharpe = calc.sharpe_ratio(&volatile_returns);
        println!("Volatile returns Sharpe: {:.2}", vol_sharpe);
    }
    
    #[test]
    fn test_max_drawdown() {
        let calc = MetricsCalculator::daily();
        
        let equity = vec![100.0, 105.0, 110.0, 95.0, 100.0, 108.0, 120.0];
        let (dd_pct, dd_usd, duration) = calc.max_drawdown(&equity);
        
        println!("Max DD: {:.1}% (${:.2}), duration: {} periods", dd_pct, dd_usd, duration);
        
        // Max DD should be from 110 to 95 = 13.6%
        assert!((dd_pct - 13.6).abs() < 0.5);
    }
    
    #[test]
    fn test_profit_factor() {
        let wins = vec![100.0, 50.0, 75.0];  // Total: 225
        let losses = vec![-30.0, -20.0, -25.0];  // Total: 75
        
        let pf = MetricsCalculator::profit_factor(&wins, &losses);
        assert!((pf - 3.0).abs() < 0.01);  // 225 / 75 = 3.0
    }
}
