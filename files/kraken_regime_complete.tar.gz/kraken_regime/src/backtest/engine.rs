//! Backtesting Engine
//!
//! Core backtesting engine that simulates trading with realistic costs.

use super::costs::{TradingCosts, TradeCostBreakdown};
use super::metrics::{PerformanceMetrics, MetricsCalculator, RegimeMetrics};
use crate::data::types::Candle;
use crate::regime::{MarketRegime, RegimeDetector};
use crate::strategy::router::{StrategyRouter, StrategyRouterConfig, RoutedSignal, ActiveStrategy};
use crate::strategy::mean_reversion::Signal;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use tracing::{debug, info};

/// Backtest configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BacktestConfig {
    /// Starting capital
    pub initial_capital: f64,
    /// Trading costs
    #[serde(skip)]
    pub costs: TradingCosts,
    /// Risk per trade (percentage of capital)
    pub risk_per_trade: f64,
    /// Maximum position size (USD)
    pub max_position_size: f64,
    /// Minimum position size (USD)
    pub min_position_size: f64,
    /// Use stops and take profits from signals
    pub use_stops: bool,
    /// Strategy router config
    #[serde(skip)]
    pub router_config: StrategyRouterConfig,
    /// Log individual trades
    pub log_trades: bool,
}

impl Default for BacktestConfig {
    fn default() -> Self {
        Self {
            initial_capital: 10000.0,
            costs: TradingCosts::kraken_standard(),
            risk_per_trade: 0.01,  // 1%
            max_position_size: 2500.0,
            min_position_size: 10.0,
            use_stops: true,
            router_config: StrategyRouterConfig::default(),
            log_trades: false,
        }
    }
}

/// A single trade record
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Trade {
    pub id: u32,
    pub entry_time: i64,
    pub exit_time: i64,
    pub entry_price: f64,
    pub exit_price: f64,
    pub size_usd: f64,
    pub pnl_gross: f64,
    pub pnl_net: f64,
    pub fees: f64,
    pub slippage: f64,
    pub regime: String,
    pub strategy: String,
    pub exit_reason: String,
}

impl Trade {
    pub fn duration_hours(&self) -> f64 {
        (self.exit_time - self.entry_time) as f64 / 3600.0
    }
    
    pub fn return_pct(&self) -> f64 {
        self.pnl_net / self.size_usd * 100.0
    }
}

/// Position tracking
#[derive(Debug, Clone)]
struct Position {
    entry_time: i64,
    entry_price: f64,
    size_usd: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
    regime: String,
    strategy: String,
}

/// Backtest result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BacktestResult {
    /// Performance metrics
    pub metrics: PerformanceMetrics,
    /// All trades
    pub trades: Vec<Trade>,
    /// Equity curve (one value per bar)
    pub equity_curve: Vec<f64>,
    /// Regime over time
    pub regime_history: Vec<(i64, String)>,
    /// Configuration used
    pub config: BacktestConfig,
    /// Number of bars processed
    pub bars_processed: usize,
}

/// Main backtesting engine
pub struct Backtester {
    config: BacktestConfig,
    router: StrategyRouter,
    
    // State
    equity: f64,
    position: Option<Position>,
    trades: Vec<Trade>,
    trade_counter: u32,
    equity_curve: Vec<f64>,
    regime_history: Vec<(i64, String)>,
    
    // For metrics
    daily_returns: Vec<f64>,
    bars_in_market: usize,
    regime_trades: HashMap<String, Vec<Trade>>,
    
    // Tracking
    total_fees: f64,
    total_slippage: f64,
    last_equity: f64,
}

impl Backtester {
    /// Create new backtester
    pub fn new(config: BacktestConfig) -> Self {
        let router = StrategyRouter::new(config.router_config.clone());
        
        Self {
            equity: config.initial_capital,
            config,
            router,
            position: None,
            trades: Vec::new(),
            trade_counter: 0,
            equity_curve: Vec::new(),
            regime_history: Vec::new(),
            daily_returns: Vec::new(),
            bars_in_market: 0,
            regime_trades: HashMap::new(),
            total_fees: 0.0,
            total_slippage: 0.0,
            last_equity: 0.0,
        }
    }
    
    /// Run backtest on candle data
    pub fn run(&mut self, symbol: &str, candles: &[Candle]) -> BacktestResult {
        info!("Running backtest on {} candles for {}", candles.len(), symbol);
        
        self.router.register_asset(symbol);
        self.last_equity = self.config.initial_capital;
        
        let mut prev_close = None;
        let mut daily_start_equity = self.equity;
        let mut current_day = 0i64;
        
        for candle in candles {
            // Track daily returns
            let candle_day = candle.timestamp / 86400;
            if candle_day != current_day && current_day != 0 {
                let daily_return = (self.equity - daily_start_equity) / daily_start_equity;
                self.daily_returns.push(daily_return);
                daily_start_equity = self.equity;
            }
            current_day = candle_day;
            
            // Get signal from router
            let signal = self.router.update(symbol, candle.high, candle.low, candle.close);
            
            // Track regime
            if let Some(regime) = self.router.get_regime(symbol) {
                self.regime_history.push((candle.timestamp, regime.to_string()));
            }
            
            // Process existing position (check stops)
            self.check_stops(candle);
            
            // Process signal
            if let Some(sig) = signal {
                self.process_signal(candle, &sig);
            }
            
            // Track exposure
            if self.position.is_some() {
                self.bars_in_market += 1;
            }
            
            // Mark-to-market
            self.update_equity(candle);
            self.equity_curve.push(self.equity);
            
            prev_close = Some(candle.close);
        }
        
        // Close any open position at end
        if let Some(pos) = self.position.take() {
            if let Some(last) = candles.last() {
                self.close_position(last, &pos, "End of backtest");
            }
        }
        
        // Calculate final metrics
        let metrics = self.calculate_metrics(candles.len());
        
        BacktestResult {
            metrics,
            trades: self.trades.clone(),
            equity_curve: self.equity_curve.clone(),
            regime_history: self.regime_history.clone(),
            config: self.config.clone(),
            bars_processed: candles.len(),
        }
    }
    
    /// Process a trading signal
    fn process_signal(&mut self, candle: &Candle, signal: &RoutedSignal) {
        match signal.signal {
            Signal::Buy if self.position.is_none() => {
                self.open_position(candle, signal);
            }
            Signal::Sell if self.position.is_some() => {
                if let Some(pos) = self.position.take() {
                    self.close_position(candle, &pos, "Signal");
                }
            }
            _ => {}
        }
    }
    
    /// Open a new position
    fn open_position(&mut self, candle: &Candle, signal: &RoutedSignal) {
        // Calculate position size
        let risk_amount = self.equity * self.config.risk_per_trade;
        let size = (risk_amount * signal.position_size_factor)
            .min(self.config.max_position_size)
            .max(self.config.min_position_size);
        
        if size > self.equity * 0.95 {
            return;  // Don't overleverage
        }
        
        // Apply entry slippage
        let entry_price = self.config.costs.apply_entry_slippage(candle.close, size, true);
        
        self.position = Some(Position {
            entry_time: candle.timestamp,
            entry_price,
            size_usd: size,
            stop_loss: if self.config.use_stops { signal.stop_loss } else { None },
            take_profit: if self.config.use_stops { signal.take_profit } else { None },
            regime: signal.regime.to_string(),
            strategy: signal.source_strategy.to_string(),
        });
        
        if self.config.log_trades {
            debug!(
                "OPEN: {} @ ${:.2}, size=${:.0}, regime={}, strategy={}",
                candle.timestamp, entry_price, size, signal.regime, signal.source_strategy
            );
        }
    }
    
    /// Close an existing position
    fn close_position(&mut self, candle: &Candle, pos: &Position, reason: &str) {
        // Apply exit slippage
        let exit_price = self.config.costs.apply_exit_slippage(candle.close, pos.size_usd, true);
        
        // Calculate P&L
        let gross_pnl = (exit_price - pos.entry_price) / pos.entry_price * pos.size_usd;
        
        // Calculate costs
        let cost_breakdown = self.config.costs.calculate_trade_costs(
            pos.entry_price,
            exit_price,
            pos.size_usd,
            false,  // Assume taker
        );
        
        let net_pnl = gross_pnl - cost_breakdown.total;
        
        // Update equity
        self.equity += net_pnl;
        self.total_fees += cost_breakdown.total_fees();
        self.total_slippage += cost_breakdown.total_slippage();
        
        // Record trade
        self.trade_counter += 1;
        let trade = Trade {
            id: self.trade_counter,
            entry_time: pos.entry_time,
            exit_time: candle.timestamp,
            entry_price: pos.entry_price,
            exit_price,
            size_usd: pos.size_usd,
            pnl_gross: gross_pnl,
            pnl_net: net_pnl,
            fees: cost_breakdown.total_fees(),
            slippage: cost_breakdown.total_slippage(),
            regime: pos.regime.clone(),
            strategy: pos.strategy.clone(),
            exit_reason: reason.to_string(),
        };
        
        // Track by regime
        self.regime_trades
            .entry(pos.regime.clone())
            .or_insert_with(Vec::new)
            .push(trade.clone());
        
        self.trades.push(trade);
        
        if self.config.log_trades {
            debug!(
                "CLOSE: {} @ ${:.2}, P&L=${:.2} (fees=${:.2}), reason={}",
                candle.timestamp, exit_price, net_pnl, cost_breakdown.total, reason
            );
        }
    }
    
    /// Check stop loss and take profit
    fn check_stops(&mut self, candle: &Candle) {
        if let Some(ref pos) = self.position.clone() {
            // Check stop loss
            if let Some(stop) = pos.stop_loss {
                if candle.low <= stop {
                    self.position = None;
                    self.close_position_at_price(candle, pos, stop, "Stop Loss");
                    return;
                }
            }
            
            // Check take profit
            if let Some(tp) = pos.take_profit {
                if candle.high >= tp {
                    self.position = None;
                    self.close_position_at_price(candle, pos, tp, "Take Profit");
                    return;
                }
            }
        }
    }
    
    /// Close position at a specific price (for stops/TPs)
    fn close_position_at_price(&mut self, candle: &Candle, pos: Position, price: f64, reason: &str) {
        // Apply slippage at stop price (usually worse)
        let exit_price = if reason == "Stop Loss" {
            price * 0.999  // Stops often slip
        } else {
            price
        };
        
        let gross_pnl = (exit_price - pos.entry_price) / pos.entry_price * pos.size_usd;
        
        let cost_breakdown = self.config.costs.calculate_trade_costs(
            pos.entry_price,
            exit_price,
            pos.size_usd,
            false,
        );
        
        let net_pnl = gross_pnl - cost_breakdown.total;
        
        self.equity += net_pnl;
        self.total_fees += cost_breakdown.total_fees();
        self.total_slippage += cost_breakdown.total_slippage();
        
        self.trade_counter += 1;
        let trade = Trade {
            id: self.trade_counter,
            entry_time: pos.entry_time,
            exit_time: candle.timestamp,
            entry_price: pos.entry_price,
            exit_price,
            size_usd: pos.size_usd,
            pnl_gross: gross_pnl,
            pnl_net: net_pnl,
            fees: cost_breakdown.total_fees(),
            slippage: cost_breakdown.total_slippage(),
            regime: pos.regime.clone(),
            strategy: pos.strategy.clone(),
            exit_reason: reason.to_string(),
        };
        
        self.regime_trades
            .entry(pos.regime.clone())
            .or_insert_with(Vec::new)
            .push(trade.clone());
        
        self.trades.push(trade);
    }
    
    /// Update equity based on open position mark-to-market
    fn update_equity(&mut self, candle: &Candle) {
        if let Some(ref pos) = self.position {
            let unrealized = (candle.close - pos.entry_price) / pos.entry_price * pos.size_usd;
            // Note: equity_curve shows unrealized gains
            // Actual equity changes only on close
        }
    }
    
    /// Calculate final performance metrics
    fn calculate_metrics(&self, total_bars: usize) -> PerformanceMetrics {
        let calc = MetricsCalculator::m15();  // Assuming 15-min bars
        
        let mut metrics = PerformanceMetrics::empty();
        
        // Returns
        metrics.total_return_usd = self.equity - self.config.initial_capital;
        metrics.total_return_pct = metrics.total_return_usd / self.config.initial_capital * 100.0;
        
        if !self.daily_returns.is_empty() {
            metrics.daily_return_mean = self.daily_returns.iter().sum::<f64>() / self.daily_returns.len() as f64;
            let var: f64 = self.daily_returns.iter()
                .map(|r| (r - metrics.daily_return_mean).powi(2))
                .sum::<f64>() / self.daily_returns.len() as f64;
            metrics.daily_return_std = var.sqrt();
        }
        
        metrics.cagr = calc.cagr(self.config.initial_capital, self.equity, total_bars);
        
        // Risk metrics
        metrics.sharpe_ratio = calc.sharpe_ratio(&self.daily_returns);
        metrics.sortino_ratio = calc.sortino_ratio(&self.daily_returns);
        
        let (dd_pct, dd_usd, dd_duration) = calc.max_drawdown(&self.equity_curve);
        metrics.max_drawdown_pct = dd_pct;
        metrics.max_drawdown_usd = dd_usd;
        metrics.max_drawdown_duration_days = dd_duration as f64 / 96.0;  // 96 15-min bars per day
        
        metrics.avg_drawdown_pct = calc.avg_drawdown(&self.equity_curve);
        metrics.ulcer_index = calc.ulcer_index(&self.equity_curve);
        metrics.calmar_ratio = calc.calmar_ratio(metrics.cagr, metrics.max_drawdown_pct);
        
        // Trade statistics
        metrics.total_trades = self.trades.len() as u32;
        
        let wins: Vec<f64> = self.trades.iter()
            .filter(|t| t.pnl_net > 0.0)
            .map(|t| t.pnl_net)
            .collect();
        let losses: Vec<f64> = self.trades.iter()
            .filter(|t| t.pnl_net <= 0.0)
            .map(|t| t.pnl_net)
            .collect();
        
        metrics.winning_trades = wins.len() as u32;
        metrics.losing_trades = losses.len() as u32;
        metrics.win_rate = if metrics.total_trades > 0 {
            metrics.winning_trades as f64 / metrics.total_trades as f64 * 100.0
        } else {
            0.0
        };
        
        metrics.profit_factor = MetricsCalculator::profit_factor(&wins, &losses);
        
        metrics.avg_win = if !wins.is_empty() { wins.iter().sum::<f64>() / wins.len() as f64 } else { 0.0 };
        metrics.avg_loss = if !losses.is_empty() { losses.iter().sum::<f64>() / losses.len() as f64 } else { 0.0 };
        
        metrics.largest_win = wins.iter().copied().fold(0.0, f64::max);
        metrics.largest_loss = losses.iter().copied().fold(0.0, f64::min);
        
        if !self.trades.is_empty() {
            metrics.avg_trade_duration_hours = self.trades.iter()
                .map(|t| t.duration_hours())
                .sum::<f64>() / self.trades.len() as f64;
            
            let total_days = total_bars as f64 / 96.0;
            metrics.trades_per_day = self.trades.len() as f64 / total_days;
        }
        
        // Exposure
        metrics.time_in_market_pct = self.bars_in_market as f64 / total_bars as f64 * 100.0;
        
        if !self.trades.is_empty() {
            metrics.avg_position_size = self.trades.iter()
                .map(|t| t.size_usd)
                .sum::<f64>() / self.trades.len() as f64;
            metrics.max_position_size = self.trades.iter()
                .map(|t| t.size_usd)
                .fold(0.0, f64::max);
        }
        
        // Costs
        metrics.total_fees = self.total_fees;
        metrics.total_slippage = self.total_slippage;
        metrics.total_costs = self.total_fees + self.total_slippage;
        
        let gross_profit: f64 = self.trades.iter().map(|t| t.pnl_gross).sum();
        metrics.costs_as_pct_of_profit = if gross_profit > 0.0 {
            metrics.total_costs / gross_profit * 100.0
        } else {
            0.0
        };
        
        // Regime breakdown
        let mut regime_metrics = HashMap::new();
        for (regime, trades) in &self.regime_trades {
            let regime_wins: Vec<f64> = trades.iter()
                .filter(|t| t.pnl_net > 0.0)
                .map(|t| t.pnl_net)
                .collect();
            let regime_losses: Vec<f64> = trades.iter()
                .filter(|t| t.pnl_net <= 0.0)
                .map(|t| t.pnl_net)
                .collect();
            
            let total_pnl: f64 = trades.iter().map(|t| t.pnl_net).sum();
            
            regime_metrics.insert(regime.clone(), RegimeMetrics {
                regime: regime.clone(),
                trades: trades.len() as u32,
                winning_trades: regime_wins.len() as u32,
                win_rate: if !trades.is_empty() { 
                    regime_wins.len() as f64 / trades.len() as f64 * 100.0 
                } else { 0.0 },
                total_pnl,
                avg_pnl: if !trades.is_empty() { total_pnl / trades.len() as f64 } else { 0.0 },
                profit_factor: MetricsCalculator::profit_factor(&regime_wins, &regime_losses),
                bars_in_regime: 0,  // Would need separate tracking
            });
        }
        metrics.regime_metrics = Some(regime_metrics);
        
        metrics
    }
    
    /// Reset for another run
    pub fn reset(&mut self) {
        self.equity = self.config.initial_capital;
        self.position = None;
        self.trades.clear();
        self.trade_counter = 0;
        self.equity_curve.clear();
        self.regime_history.clear();
        self.daily_returns.clear();
        self.bars_in_market = 0;
        self.regime_trades.clear();
        self.total_fees = 0.0;
        self.total_slippage = 0.0;
        self.router = StrategyRouter::new(self.config.router_config.clone());
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    fn generate_test_candles(n: usize, start_price: f64, trend: f64) -> Vec<Candle> {
        let mut candles = Vec::new();
        let mut price = start_price;
        
        for i in 0..n {
            let noise = (i as f64 * 0.1).sin() * 50.0;
            price += trend + noise;
            price = price.max(1.0);
            
            let high = price + price * 0.01;
            let low = price - price * 0.01;
            
            candles.push(Candle {
                timestamp: i as i64 * 900,  // 15-min bars
                open: price - trend/2.0,
                high,
                low,
                close: price,
                volume: 100.0,
            });
        }
        candles
    }
    
    #[test]
    fn test_backtest_basic() {
        let config = BacktestConfig::default();
        let mut bt = Backtester::new(config);
        
        let candles = generate_test_candles(1000, 50000.0, 10.0);  // Uptrend
        let result = bt.run("BTC/USD", &candles);
        
        println!("Trades: {}", result.trades.len());
        println!("Final equity: ${:.2}", result.metrics.total_return_usd + 10000.0);
        
        result.metrics.print_summary();
    }
    
    #[test]
    fn test_costs_impact() {
        // Run with costs
        let config_with_costs = BacktestConfig::default();
        let mut bt1 = Backtester::new(config_with_costs);
        
        // Run without costs
        let config_no_costs = BacktestConfig {
            costs: TradingCosts::zero(),
            ..Default::default()
        };
        let mut bt2 = Backtester::new(config_no_costs);
        
        let candles = generate_test_candles(500, 50000.0, 5.0);
        
        let result1 = bt1.run("BTC/USD", &candles);
        bt2.reset();
        let result2 = bt2.run("BTC/USD", &candles);
        
        println!("With costs:    ${:.2}", result1.metrics.total_return_usd);
        println!("Without costs: ${:.2}", result2.metrics.total_return_usd);
        println!("Cost impact:   ${:.2}", result2.metrics.total_return_usd - result1.metrics.total_return_usd);
    }
}
