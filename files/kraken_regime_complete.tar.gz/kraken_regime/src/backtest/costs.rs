//! Trading Costs and Slippage Models
//!
//! Realistic simulation of trading costs including:
//! - Exchange fees (maker/taker)
//! - Slippage (spread, market impact)
//! - Network fees (for crypto)

use serde::{Deserialize, Serialize};

/// Trading costs configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TradingCosts {
    /// Maker fee as decimal (0.001 = 0.1%)
    pub maker_fee: f64,
    /// Taker fee as decimal (0.002 = 0.2%)
    pub taker_fee: f64,
    /// Fixed fee per trade in USD (for network fees etc)
    pub fixed_fee_usd: f64,
    /// Slippage model
    pub slippage: SlippageModel,
}

impl TradingCosts {
    /// Create new trading costs
    pub fn new(maker_fee: f64, taker_fee: f64) -> Self {
        Self {
            maker_fee,
            taker_fee,
            fixed_fee_usd: 0.0,
            slippage: SlippageModel::default(),
        }
    }
    
    /// Kraken standard fees (most common tier)
    pub fn kraken_standard() -> Self {
        Self {
            maker_fee: 0.0016,  // 0.16%
            taker_fee: 0.0026,  // 0.26%
            fixed_fee_usd: 0.0,
            slippage: SlippageModel::kraken_default(),
        }
    }
    
    /// Kraken intermediate fees (higher volume)
    pub fn kraken_intermediate() -> Self {
        Self {
            maker_fee: 0.0014,  // 0.14%
            taker_fee: 0.0024,  // 0.24%
            fixed_fee_usd: 0.0,
            slippage: SlippageModel::kraken_default(),
        }
    }
    
    /// Kraken pro fees (high volume)
    pub fn kraken_pro() -> Self {
        Self {
            maker_fee: 0.0010,  // 0.10%
            taker_fee: 0.0020,  // 0.20%
            fixed_fee_usd: 0.0,
            slippage: SlippageModel::low_slippage(),
        }
    }
    
    /// Zero fees (for testing)
    pub fn zero() -> Self {
        Self {
            maker_fee: 0.0,
            taker_fee: 0.0,
            fixed_fee_usd: 0.0,
            slippage: SlippageModel::none(),
        }
    }
    
    /// Conservative estimate (pessimistic)
    pub fn conservative() -> Self {
        Self {
            maker_fee: 0.002,   // 0.20%
            taker_fee: 0.003,   // 0.30%
            fixed_fee_usd: 0.10,
            slippage: SlippageModel::high_slippage(),
        }
    }
    
    /// Calculate total cost for a trade
    /// Returns (entry_cost, exit_cost) in USD
    pub fn calculate_trade_costs(
        &self,
        entry_price: f64,
        exit_price: f64,
        size_usd: f64,
        is_maker: bool,
    ) -> TradeCostBreakdown {
        let fee_rate = if is_maker { self.maker_fee } else { self.taker_fee };
        
        // Entry costs
        let entry_fee = size_usd * fee_rate;
        let entry_slippage = self.slippage.calculate(entry_price, size_usd, true);
        let entry_slippage_cost = entry_slippage * (size_usd / entry_price);
        
        // Exit costs
        let exit_notional = size_usd * (exit_price / entry_price);
        let exit_fee = exit_notional * fee_rate;
        let exit_slippage = self.slippage.calculate(exit_price, exit_notional, false);
        let exit_slippage_cost = exit_slippage * (exit_notional / exit_price);
        
        TradeCostBreakdown {
            entry_fee,
            entry_slippage: entry_slippage_cost,
            exit_fee,
            exit_slippage: exit_slippage_cost,
            fixed_fees: self.fixed_fee_usd * 2.0,  // Entry + exit
            total: entry_fee + entry_slippage_cost + exit_fee + exit_slippage_cost + self.fixed_fee_usd * 2.0,
        }
    }
    
    /// Apply slippage to entry price
    pub fn apply_entry_slippage(&self, price: f64, size_usd: f64, is_buy: bool) -> f64 {
        let slippage = self.slippage.calculate(price, size_usd, is_buy);
        if is_buy {
            price + slippage  // Pay more when buying
        } else {
            price - slippage  // Receive less when selling
        }
    }
    
    /// Apply slippage to exit price
    pub fn apply_exit_slippage(&self, price: f64, size_usd: f64, is_buy: bool) -> f64 {
        // Exit is opposite of entry
        self.apply_entry_slippage(price, size_usd, !is_buy)
    }
}

impl Default for TradingCosts {
    fn default() -> Self {
        Self::kraken_standard()
    }
}

/// Breakdown of costs for a single trade
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TradeCostBreakdown {
    pub entry_fee: f64,
    pub entry_slippage: f64,
    pub exit_fee: f64,
    pub exit_slippage: f64,
    pub fixed_fees: f64,
    pub total: f64,
}

impl TradeCostBreakdown {
    /// Total fees (excluding slippage)
    pub fn total_fees(&self) -> f64 {
        self.entry_fee + self.exit_fee + self.fixed_fees
    }
    
    /// Total slippage
    pub fn total_slippage(&self) -> f64 {
        self.entry_slippage + self.exit_slippage
    }
}

/// Slippage simulation model
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SlippageModel {
    /// Base spread as decimal (0.001 = 0.1%)
    pub base_spread: f64,
    /// Market impact coefficient (larger orders = more slippage)
    pub market_impact_coefficient: f64,
    /// Market impact exponent (usually 0.5-1.0)
    pub market_impact_exponent: f64,
    /// Minimum slippage in price units
    pub min_slippage_pct: f64,
    /// Maximum slippage as percentage of price
    pub max_slippage_pct: f64,
    /// Random component (0 = deterministic)
    pub randomness: f64,
}

impl SlippageModel {
    /// Create new slippage model
    pub fn new(base_spread: f64) -> Self {
        Self {
            base_spread,
            market_impact_coefficient: 0.0001,
            market_impact_exponent: 0.5,
            min_slippage_pct: 0.0,
            max_slippage_pct: 0.01,  // Max 1%
            randomness: 0.0,
        }
    }
    
    /// No slippage (for testing)
    pub fn none() -> Self {
        Self {
            base_spread: 0.0,
            market_impact_coefficient: 0.0,
            market_impact_exponent: 0.5,
            min_slippage_pct: 0.0,
            max_slippage_pct: 0.0,
            randomness: 0.0,
        }
    }
    
    /// Default for Kraken (BTC/USD typically has ~$1-5 spread)
    pub fn kraken_default() -> Self {
        Self {
            base_spread: 0.0002,  // 0.02% (about $20 on $100k BTC)
            market_impact_coefficient: 0.00005,
            market_impact_exponent: 0.5,
            min_slippage_pct: 0.0001,
            max_slippage_pct: 0.005,  // Max 0.5%
            randomness: 0.2,
        }
    }
    
    /// Low slippage (high volume pairs, limit orders)
    pub fn low_slippage() -> Self {
        Self {
            base_spread: 0.0001,
            market_impact_coefficient: 0.00002,
            market_impact_exponent: 0.5,
            min_slippage_pct: 0.0,
            max_slippage_pct: 0.002,
            randomness: 0.1,
        }
    }
    
    /// High slippage (low volume pairs, market orders)
    pub fn high_slippage() -> Self {
        Self {
            base_spread: 0.0005,
            market_impact_coefficient: 0.0002,
            market_impact_exponent: 0.6,
            min_slippage_pct: 0.0002,
            max_slippage_pct: 0.01,
            randomness: 0.3,
        }
    }
    
    /// Calculate slippage in price units
    /// 
    /// # Arguments
    /// * `price` - Current market price
    /// * `size_usd` - Order size in USD
    /// * `is_buy` - Whether this is a buy order
    pub fn calculate(&self, price: f64, size_usd: f64, _is_buy: bool) -> f64 {
        // Base spread
        let spread_slippage = price * self.base_spread / 2.0;
        
        // Market impact (square root model)
        let impact = self.market_impact_coefficient 
            * size_usd.powf(self.market_impact_exponent);
        let impact_slippage = price * impact;
        
        // Add randomness if configured
        let random_factor = if self.randomness > 0.0 {
            let rand_val = (std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .subsec_nanos() as f64 / 1e9) * 2.0 - 1.0;  // -1 to 1
            1.0 + rand_val * self.randomness
        } else {
            1.0
        };
        
        let total = (spread_slippage + impact_slippage) * random_factor;
        
        // Apply min/max bounds
        let min = price * self.min_slippage_pct;
        let max = price * self.max_slippage_pct;
        
        total.max(min).min(max)
    }
    
    /// Estimate slippage percentage for a given order size
    pub fn estimate_slippage_pct(&self, price: f64, size_usd: f64) -> f64 {
        self.calculate(price, size_usd, true) / price * 100.0
    }
}

impl Default for SlippageModel {
    fn default() -> Self {
        Self::kraken_default()
    }
}

/// Realistic slippage for different asset types
pub fn get_slippage_for_asset(pair: &str) -> SlippageModel {
    let upper = pair.to_uppercase();
    
    // Major pairs (high liquidity)
    if upper.contains("BTC") || upper.contains("ETH") {
        SlippageModel::kraken_default()
    }
    // Mid-tier (decent liquidity)
    else if upper.contains("SOL") || upper.contains("XRP") || upper.contains("ADA") {
        SlippageModel {
            base_spread: 0.0003,
            market_impact_coefficient: 0.0001,
            ..SlippageModel::kraken_default()
        }
    }
    // Low liquidity (memecoins, small caps)
    else if upper.contains("DOGE") || upper.contains("PEPE") || upper.contains("WIF") || upper.contains("FART") {
        SlippageModel::high_slippage()
    }
    // Default
    else {
        SlippageModel::kraken_default()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_fee_calculation() {
        let costs = TradingCosts::kraken_standard();
        
        let breakdown = costs.calculate_trade_costs(
            100.0,   // entry price
            110.0,   // exit price (10% profit)
            1000.0,  // $1000 position
            false,   // taker
        );
        
        // Entry fee: $1000 * 0.26% = $2.60
        assert!((breakdown.entry_fee - 2.60).abs() < 0.1);
        
        // Exit fee: $1100 * 0.26% = $2.86
        assert!((breakdown.exit_fee - 2.86).abs() < 0.1);
        
        println!("Trade cost breakdown: {:?}", breakdown);
    }
    
    #[test]
    fn test_slippage_model() {
        let model = SlippageModel::kraken_default();
        
        // Small order should have low slippage
        let small_slip = model.estimate_slippage_pct(100000.0, 1000.0);
        println!("$1K order slippage: {:.4}%", small_slip);
        assert!(small_slip < 0.1);
        
        // Large order should have higher slippage
        let large_slip = model.estimate_slippage_pct(100000.0, 100000.0);
        println!("$100K order slippage: {:.4}%", large_slip);
        assert!(large_slip > small_slip);
    }
    
    #[test]
    fn test_entry_slippage() {
        let costs = TradingCosts::kraken_standard();
        
        let price = 100000.0;
        let slipped = costs.apply_entry_slippage(price, 1000.0, true);
        
        // When buying, price should be higher
        assert!(slipped > price);
        println!("Entry slip: ${} -> ${}", price, slipped);
    }
}
