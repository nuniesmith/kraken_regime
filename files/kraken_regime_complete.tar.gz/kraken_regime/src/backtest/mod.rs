//! Backtesting Module
//!
//! Professional backtesting engine with:
//! - Realistic fees and slippage simulation
//! - Walk-forward analysis
//! - Performance metrics (Sharpe, Sortino, Max DD, etc.)
//! - Trade logging and analysis

pub mod engine;
pub mod metrics;
pub mod costs;
pub mod walk_forward;

pub use engine::{Backtester, BacktestConfig, BacktestResult};
pub use metrics::PerformanceMetrics;
pub use costs::{TradingCosts, SlippageModel};
pub use walk_forward::{WalkForwardAnalysis, WalkForwardConfig, WalkForwardResult};
