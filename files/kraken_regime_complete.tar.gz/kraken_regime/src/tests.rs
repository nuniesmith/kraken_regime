//! Comprehensive Test Suite
//!
//! This module contains all tests for the trading system:
//! - Unit tests for individual components
//! - Integration tests for the full system
//! - Property-based tests for edge cases

use crate::data::types::{Candle, Timeframe, TradingPair};
use crate::regime::{RegimeDetector, RegimeConfig, MarketRegime, HMMRegimeDetector, HMMConfig};
use crate::regime::indicators::{EMA, ATR, ADX, BollingerBands};
use crate::strategy::mean_reversion::{MeanReversionStrategy, MeanReversionConfig, Signal};
use crate::strategy::router::{StrategyRouter, StrategyRouterConfig};
use crate::backtest::costs::{TradingCosts, SlippageModel};

// ============================================================================
// INDICATOR TESTS
// ============================================================================

#[cfg(test)]
mod indicator_tests {
    use super::*;
    
    #[test]
    fn test_ema_calculation() {
        let mut ema = EMA::new(3);
        
        // Feed some values
        let values = [10.0, 11.0, 12.0, 11.0, 13.0];
        let mut results = Vec::new();
        
        for v in values {
            if let Some(r) = ema.update(v) {
                results.push(r);
            }
        }
        
        // EMA should smooth the values
        assert!(results.len() >= 2);
        println!("EMA results: {:?}", results);
    }
    
    #[test]
    fn test_ema_convergence() {
        let mut ema = EMA::new(10);
        
        // Feed constant value - EMA should converge to it
        for _ in 0..50 {
            ema.update(100.0);
        }
        
        let result = ema.value().unwrap();
        assert!((result - 100.0).abs() < 0.1, "EMA should converge to 100, got {}", result);
    }
    
    #[test]
    fn test_atr_calculation() {
        let mut atr = ATR::new(3);
        
        // Simulate some price action
        let bars = [
            (100.0, 102.0, 98.0, 101.0),   // Range = 4
            (101.0, 104.0, 100.0, 103.0),  // Range = 4, TR includes prev close
            (103.0, 106.0, 102.0, 105.0),
            (105.0, 107.0, 103.0, 106.0),
        ];
        
        for (open, high, low, close) in bars {
            atr.update(high, low, close);
        }
        
        let result = atr.value().unwrap();
        println!("ATR result: {}", result);
        assert!(result > 0.0, "ATR should be positive");
    }
    
    #[test]
    fn test_adx_trending_market() {
        let mut adx = ADX::new(14);
        
        // Simulate strong uptrend
        let mut price = 100.0;
        for i in 0..30 {
            price += 2.0 + (i as f64 * 0.1).sin();  // Consistent upward
            let high = price + 1.0;
            let low = price - 0.5;
            adx.update(high, low, price);
        }
        
        if let Some(value) = adx.value() {
            println!("ADX in uptrend: {}", value);
            // ADX should be elevated in trending market
            // Note: May need more bars to fully calculate
        }
    }
    
    #[test]
    fn test_bollinger_bands_basics() {
        let mut bb = BollingerBands::new(5, 2.0);
        
        let prices = [100.0, 101.0, 99.0, 102.0, 100.0, 103.0, 98.0, 101.0];
        
        for price in prices {
            if let Some(values) = bb.update(price) {
                println!("BB: Lower={:.2}, Middle={:.2}, Upper={:.2}, %B={:.2}",
                    values.lower, values.middle, values.upper, values.percent_b);
                
                // Basic sanity checks
                assert!(values.lower < values.middle);
                assert!(values.middle < values.upper);
                assert!(values.width > 0.0);
            }
        }
    }
    
    #[test]
    fn test_bollinger_squeeze_detection() {
        let mut bb = BollingerBands::new(5, 2.0);
        
        // Feed tight range data
        for _ in 0..20 {
            bb.update(100.0);  // No volatility
        }
        
        if let Some(values) = bb.update(100.0) {
            assert!(values.is_squeeze(50.0), "Should detect squeeze in tight range");
        }
    }
}

// ============================================================================
// REGIME DETECTION TESTS
// ============================================================================

#[cfg(test)]
mod regime_tests {
    use super::*;
    
    #[test]
    fn test_regime_detector_creation() {
        let config = RegimeConfig::crypto_optimized();
        let detector = RegimeDetector::new(config);
        
        assert!(!detector.is_ready(), "Should not be ready without data");
    }
    
    #[test]
    fn test_trending_regime_detection() {
        let mut detector = RegimeDetector::crypto_optimized();
        
        // Simulate uptrend
        let mut price = 100.0;
        for _ in 0..100 {
            price *= 1.005;  // Consistent 0.5% daily gains
            let high = price * 1.01;
            let low = price * 0.99;
            detector.update(high, low, price);
        }
        
        if detector.is_ready() {
            let regime = detector.current_regime();
            println!("Detected regime in uptrend: {:?}", regime);
            
            match regime {
                MarketRegime::Trending(_) => {
                    println!("✓ Correctly detected trending regime");
                }
                _ => {
                    println!("Detected {:?} instead of Trending", regime);
                }
            }
        }
    }
    
    #[test]
    fn test_ranging_regime_detection() {
        let mut detector = RegimeDetector::crypto_optimized();
        
        // Simulate ranging market
        let base_price = 100.0;
        for i in 0..100 {
            let price = base_price + (i as f64 * 0.1).sin() * 2.0;  // Small oscillation
            let high = price + 0.5;
            let low = price - 0.5;
            detector.update(high, low, price);
        }
        
        if detector.is_ready() {
            let regime = detector.current_regime();
            println!("Detected regime in range: {:?}", regime);
        }
    }
    
    #[test]
    fn test_volatile_regime_detection() {
        let mut detector = RegimeDetector::crypto_optimized();
        
        // Simulate volatile market
        let mut price = 100.0;
        for i in 0..100 {
            let change = if i % 2 == 0 { 1.05 } else { 0.95 };  // 5% swings
            price *= change;
            let high = price * 1.03;
            let low = price * 0.97;
            detector.update(high, low, price);
        }
        
        if detector.is_ready() {
            let regime = detector.current_regime();
            println!("Detected regime in volatile market: {:?}", regime);
        }
    }
    
    #[test]
    fn test_hmm_detector() {
        let config = HMMConfig {
            min_observations: 20,
            n_states: 3,
            ..HMMConfig::crypto_optimized()
        };
        
        let mut hmm = HMMRegimeDetector::new(config);
        
        // Feed some data
        let mut price = 100.0;
        for _ in 0..50 {
            price *= 1.002;
            hmm.update(price);
        }
        
        assert!(hmm.is_ready(), "HMM should be ready after warmup");
        
        let probs = hmm.state_probabilities();
        let sum: f64 = probs.iter().sum();
        assert!((sum - 1.0).abs() < 0.001, "Probabilities should sum to 1");
    }
    
    #[test]
    fn test_regime_confidence() {
        let mut detector = RegimeDetector::crypto_optimized();
        
        // Feed clear trend data
        let mut price = 100.0;
        for _ in 0..100 {
            price *= 1.01;
            let high = price * 1.005;
            let low = price * 0.995;
            let result = detector.update(high, low, price);
            
            if detector.is_ready() {
                assert!(result.confidence >= 0.0 && result.confidence <= 1.0,
                    "Confidence should be between 0 and 1");
            }
        }
    }
}

// ============================================================================
// STRATEGY TESTS
// ============================================================================

#[cfg(test)]
mod strategy_tests {
    use super::*;
    
    #[test]
    fn test_mean_reversion_creation() {
        let config = MeanReversionConfig::default();
        let strategy = MeanReversionStrategy::new(config);
        
        assert!(!strategy.is_ready(), "Should not be ready without data");
    }
    
    #[test]
    fn test_mean_reversion_buy_signal() {
        let config = MeanReversionConfig {
            bb_period: 10,
            bb_std_dev: 2.0,
            entry_threshold: 0.1,
            require_rsi_confirmation: false,
            ..Default::default()
        };
        
        let mut strategy = MeanReversionStrategy::new(config);
        
        // Warm up with normal prices
        let base_price = 100.0;
        for i in 0..15 {
            let price = base_price + (i as f64 * 0.1).sin();
            strategy.update(price + 1.0, price - 1.0, price);
        }
        
        // Price drops to lower band
        let low_price = base_price - 10.0;
        let signal = strategy.update(low_price + 0.5, low_price - 0.5, low_price);
        
        println!("Signal at lower band: {:?}", signal);
        // May or may not trigger depending on BB values
    }
    
    #[test]
    fn test_strategy_router() {
        let config = StrategyRouterConfig::default();
        let mut router = StrategyRouter::new(config);
        
        router.register_asset("BTC/USD");
        
        // Feed some data
        let mut price = 50000.0;
        for _ in 0..100 {
            price *= 1.002;
            let high = price * 1.01;
            let low = price * 0.99;
            
            if let Some(signal) = router.update("BTC/USD", high, low, price) {
                println!("Router signal: {:?} from {:?}", signal.signal, signal.source_strategy);
            }
        }
        
        assert!(router.is_ready("BTC/USD"), "Router should be ready after warmup");
    }
    
    #[test]
    fn test_strategy_selection_by_regime() {
        let config = StrategyRouterConfig::default();
        let mut router = StrategyRouter::new(config);
        
        router.register_asset("TEST");
        
        // Feed trending data
        let mut price = 100.0;
        for _ in 0..150 {
            price *= 1.003;
            router.update("TEST", price * 1.01, price * 0.99, price);
        }
        
        if let Some(strategy) = router.get_active_strategy("TEST") {
            println!("Active strategy after uptrend: {:?}", strategy);
        }
    }
}

// ============================================================================
// COST MODEL TESTS
// ============================================================================

#[cfg(test)]
mod cost_tests {
    use super::*;
    
    #[test]
    fn test_trading_costs_calculation() {
        let costs = TradingCosts::kraken_standard();
        
        let breakdown = costs.calculate_trade_costs(
            100.0,    // entry
            110.0,    // exit (10% profit)
            1000.0,   // size
            false,    // taker
        );
        
        // Verify costs are reasonable
        assert!(breakdown.total > 0.0, "Total costs should be positive");
        assert!(breakdown.total < 100.0, "Costs shouldn't eat entire profit");
        
        println!("Cost breakdown: {:?}", breakdown);
    }
    
    #[test]
    fn test_slippage_model() {
        let model = SlippageModel::kraken_default();
        
        // Small order
        let small = model.calculate(100000.0, 1000.0, true);
        
        // Large order
        let large = model.calculate(100000.0, 100000.0, true);
        
        assert!(large > small, "Larger orders should have more slippage");
        
        println!("Small order slippage: ${:.2}", small);
        println!("Large order slippage: ${:.2}", large);
    }
    
    #[test]
    fn test_zero_costs() {
        let costs = TradingCosts::zero();
        
        let breakdown = costs.calculate_trade_costs(100.0, 110.0, 1000.0, false);
        
        assert_eq!(breakdown.total, 0.0, "Zero costs should have no costs");
    }
    
    #[test]
    fn test_entry_slippage_direction() {
        let costs = TradingCosts::kraken_standard();
        let price = 100000.0;
        
        // When buying, we pay more
        let buy_price = costs.apply_entry_slippage(price, 1000.0, true);
        assert!(buy_price > price, "Buy price should be higher due to slippage");
        
        // When selling, we receive less
        let sell_price = costs.apply_entry_slippage(price, 1000.0, false);
        assert!(sell_price < price, "Sell price should be lower due to slippage");
    }
}

// ============================================================================
// DATA TYPE TESTS
// ============================================================================

#[cfg(test)]
mod data_tests {
    use super::*;
    
    #[test]
    fn test_candle_creation() {
        let candle = Candle::new(1000, 100.0, 110.0, 95.0, 105.0, 1000.0);
        
        assert!(candle.is_bullish());
        assert!(!candle.is_bearish());
    }
    
    #[test]
    fn test_candle_calculations() {
        let candle = Candle::new(1000, 100.0, 110.0, 95.0, 105.0, 1000.0);
        
        // Typical price = (H + L + C) / 3 = (110 + 95 + 105) / 3 = 103.33
        let typical = candle.typical_price();
        assert!((typical - 103.33).abs() < 0.1);
        
        // True range without previous close = H - L = 15
        let tr = candle.true_range(None);
        assert!((tr - 15.0).abs() < 0.1);
        
        // True range with previous close
        let tr_with_prev = candle.true_range(Some(90.0));  // Previous close was 90
        // TR = max(H-L, |H-PC|, |L-PC|) = max(15, 20, 5) = 20
        assert!((tr_with_prev - 20.0).abs() < 0.1);
    }
    
    #[test]
    fn test_trading_pair_parsing() {
        let pair1 = TradingPair::parse("BTC/USD").unwrap();
        assert_eq!(pair1.base, "BTC");
        assert_eq!(pair1.quote, "USD");
        
        let pair2 = TradingPair::parse("ETHUSD").unwrap();
        assert_eq!(pair2.base, "ETH");
        assert_eq!(pair2.quote, "USD");
    }
    
    #[test]
    fn test_kraken_pair_format() {
        let pair = TradingPair::new("BTC", "USD");
        assert_eq!(pair.kraken_format(), "XBTUSD");
        
        let eth = TradingPair::new("ETH", "USD");
        assert_eq!(eth.standard(), "ETH/USD");
    }
    
    #[test]
    fn test_timeframe() {
        assert_eq!(Timeframe::M15.minutes(), 15);
        assert_eq!(Timeframe::H1.seconds(), 3600);
        assert_eq!(Timeframe::D1.minutes(), 1440);
        
        assert_eq!(Timeframe::from_minutes(60), Some(Timeframe::H1));
        assert_eq!(Timeframe::from_minutes(42), None);
    }
}

// ============================================================================
// INTEGRATION TESTS
// ============================================================================

#[cfg(test)]
mod integration_tests {
    use super::*;
    use crate::backtest::engine::{Backtester, BacktestConfig};
    
    fn generate_test_candles(n: usize, trend: f64) -> Vec<Candle> {
        let mut candles = Vec::new();
        let mut price = 50000.0;
        
        for i in 0..n {
            let noise = (i as f64 * 0.1).sin() * 50.0;
            price += trend + noise;
            price = price.max(1.0);
            
            candles.push(Candle {
                timestamp: i as i64 * 900,
                open: price - trend / 2.0,
                high: price * 1.01,
                low: price * 0.99,
                close: price,
                volume: 100.0 + (i as f64 % 50.0),
            });
        }
        candles
    }
    
    #[test]
    fn test_full_backtest_pipeline() {
        let config = BacktestConfig {
            initial_capital: 10000.0,
            costs: TradingCosts::kraken_standard(),
            risk_per_trade: 0.01,
            max_position_size: 2500.0,
            min_position_size: 10.0,
            use_stops: true,
            log_trades: false,
            ..Default::default()
        };
        
        let mut backtester = Backtester::new(config);
        let candles = generate_test_candles(1000, 10.0);  // Uptrending
        
        let result = backtester.run("BTC/USD", &candles);
        
        // Verify result structure
        assert_eq!(result.bars_processed, 1000);
        assert!(!result.equity_curve.is_empty());
        
        println!("\nBacktest completed:");
        println!("  Trades: {}", result.trades.len());
        println!("  Final return: {:.2}%", result.metrics.total_return_pct);
        println!("  Sharpe ratio: {:.2}", result.metrics.sharpe_ratio);
        println!("  Max drawdown: {:.2}%", result.metrics.max_drawdown_pct);
    }
    
    #[test]
    fn test_regime_to_strategy_pipeline() {
        let mut router = StrategyRouter::default_config();
        router.register_asset("BTC/USD");
        
        // Phase 1: Feed trending data
        let mut price = 100.0;
        let mut trending_signals = 0;
        let mut mr_signals = 0;
        
        for _ in 0..100 {
            price *= 1.003;
            if let Some(signal) = router.update("BTC/USD", price * 1.01, price * 0.99, price) {
                match signal.source_strategy {
                    crate::strategy::router::ActiveStrategy::TrendFollowing => trending_signals += 1,
                    crate::strategy::router::ActiveStrategy::MeanReversion => mr_signals += 1,
                    _ => {}
                }
            }
        }
        
        // Phase 2: Feed ranging data
        for i in 0..100 {
            let oscillation = (i as f64 * 0.2).sin() * 5.0;
            let p = price + oscillation;
            if let Some(signal) = router.update("BTC/USD", p * 1.01, p * 0.99, p) {
                match signal.source_strategy {
                    crate::strategy::router::ActiveStrategy::TrendFollowing => trending_signals += 1,
                    crate::strategy::router::ActiveStrategy::MeanReversion => mr_signals += 1,
                    _ => {}
                }
            }
        }
        
        println!("Trend following signals: {}", trending_signals);
        println!("Mean reversion signals: {}", mr_signals);
    }
    
    #[test]
    fn test_costs_impact_on_returns() {
        let candles = generate_test_candles(500, 5.0);
        
        // With costs
        let config_with = BacktestConfig::default();
        let mut bt_with = Backtester::new(config_with);
        let result_with = bt_with.run("BTC/USD", &candles);
        
        // Without costs
        let config_without = BacktestConfig {
            costs: TradingCosts::zero(),
            ..Default::default()
        };
        let mut bt_without = Backtester::new(config_without);
        let result_without = bt_without.run("BTC/USD", &candles);
        
        let cost_impact = result_without.metrics.total_return_usd - result_with.metrics.total_return_usd;
        
        println!("Return with costs: ${:.2}", result_with.metrics.total_return_usd);
        println!("Return without costs: ${:.2}", result_without.metrics.total_return_usd);
        println!("Cost impact: ${:.2}", cost_impact);
        
        // Costs should reduce returns
        assert!(result_without.metrics.total_return_usd >= result_with.metrics.total_return_usd,
            "Returns without costs should be >= returns with costs");
    }
}

// ============================================================================
// PROPERTY-BASED TESTS (Edge cases)
// ============================================================================

#[cfg(test)]
mod property_tests {
    use super::*;
    
    #[test]
    fn test_ema_handles_extreme_values() {
        let mut ema = EMA::new(10);
        
        // Very large values
        for _ in 0..20 {
            ema.update(1e10);
        }
        assert!(ema.value().unwrap().is_finite());
        
        // Very small values
        let mut ema2 = EMA::new(10);
        for _ in 0..20 {
            ema2.update(1e-10);
        }
        assert!(ema2.value().unwrap().is_finite());
    }
    
    #[test]
    fn test_regime_detector_handles_flat_market() {
        let mut detector = RegimeDetector::crypto_optimized();
        
        // Completely flat market
        for _ in 0..200 {
            detector.update(100.0, 100.0, 100.0);
        }
        
        // Should not crash and should return valid regime
        if detector.is_ready() {
            let regime = detector.current_regime();
            println!("Regime in flat market: {:?}", regime);
        }
    }
    
    #[test]
    fn test_slippage_handles_zero_size() {
        let model = SlippageModel::kraken_default();
        let slip = model.calculate(100000.0, 0.0, true);
        
        // Should handle gracefully
        assert!(slip.is_finite());
        assert!(slip >= 0.0);
    }
    
    #[test]
    fn test_costs_with_negative_return() {
        let costs = TradingCosts::kraken_standard();
        
        // Losing trade
        let breakdown = costs.calculate_trade_costs(
            110.0,   // entry
            100.0,   // exit (loss)
            1000.0,
            false,
        );
        
        // Costs should still be calculated correctly
        assert!(breakdown.total > 0.0);
        println!("Costs on losing trade: ${:.2}", breakdown.total);
    }
    
    #[test]
    fn test_very_small_position() {
        let costs = TradingCosts::kraken_standard();
        
        let breakdown = costs.calculate_trade_costs(
            100.0,
            101.0,
            1.0,  // $1 position
            false,
        );
        
        assert!(breakdown.total.is_finite());
        println!("Costs on $1 position: ${:.6}", breakdown.total);
    }
}
